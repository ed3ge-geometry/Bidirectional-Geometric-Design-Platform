import openseespy.opensees as op
import numpy as np
import fem



import numpy as np
import numpy.ma as ma

from pydoc import locate
import igl
import time
import datetime
from scipy.spatial import distance_matrix
from copy import deepcopy
import math
import os
from os.path import exists
import datetime


now_ML = str(datetime.datetime.now().strftime('_%Y-%m-%d_%H_%M_%S'))


def QuadShell_FEM(input_folder, now,
              save_GA = False,
              save_data = False,
              save_data_no = 0,
              data_dir = None):
    # format input .dat into numpy array
    vert_init = np.loadtxt(input_folder+"/vertex.dat")
    vert_fix = np.loadtxt(input_folder+"/fix.dat")
    face = np.loadtxt(input_folder+"/face.dat")
    # hyperparam
    vals = [None,None,None,None] # thickness, poi, mass, E
    with open(input_folder+"/hyperparams.dat") as openingfile:
        counter = 0
        for line in openingfile:
            l = line.split('#')
            vals[counter] = float(l[1])
            counter += 1
    num_nodes = vert_init.shape[0]
    num_faces = face.shape[0]

    u,sec_f,str_e = fem.elastic_analysis_quad(num_nodes,num_faces,vert_init,face,vals[3],vals[1],vals[0],vals[2],vert_fix)
    # save response
    np.savetxt(input_folder+'/u.dat',u)
    np.savetxt(input_folder+'/sec_f.dat',sec_f)
    np.savetxt(input_folder+'/str_e.dat',np.array([str_e]))
    # print maximum
    maxux=min(u[:,0])
    maxuy=min(u[:,1])
    maxuz=min(u[:,2])
    indexx=np.where(u[:,0]==maxux)
    indexy=np.where(u[:,1]==maxuy)
    indexz=np.where(u[:,2]==maxuz)

    print('Max x deformation at {} Val {}'.format(indexx,maxux))
    print('Max y deformation at {} Val {}'.format(indexy,maxuy))
    print('Max z deformation at {} Val {}'.format(indexz,maxuz))
    #print(indexxx,maxuxx)
    #print(indexyy,maxuyy)
    #print(indexzz,maxuzz)
    '''
    if save_GA:
        GA_folder = 'GA'
        if not os.path.exists(GA_folder):
        os.makedirs(GA_folder)

        np.savetxt(GA_folder+'/open_u.dat',u)
        np.savetxt(GA_folder+'/f.dat',sec_f)

    if save_data:
        ML_folder = data_dir + '/{}'.format(str(save_data_no))
        if not os.path.exists(ML_folder):
            os.makedirs(ML_folder)
            np.savetxt(ML_folder+'/open_u.dat',u)
            np.savetxt(ML_folder+'/f.dat',sec_f)

    '''

    #print(sec_f.shape)
    #print(u.shape)
    #str_e = fem.calc_strain_energy(num_nodes,sec_f,u)
    #print(str_e)

    return maxuz,str_e

script_dir =os.path.dirname(os.path.abspath(__file__))
out_dir = os.path.join(script_dir,'out')

maxuz,str_e = QuadShell_FEM(out_dir,now_ML)

print(maxuz)
print(str_e)
