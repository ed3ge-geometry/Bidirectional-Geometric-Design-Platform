import yaml
import re
import os

import ast

def convert_dat_to_yaml(input_dir, output_dir):
    input_file = input_dir
    output_file = output_dir
    #input_file = os.path.join(input_dir, 'NN.dat')
    #output_file = os.path.join(output_dir, 'config.yaml')

    # Read the NN.dat file
    with open(input_file, 'r') as file:
        lines = file.readlines()

    # Initialize a dictionary to store the configuration
    config = {
        'seed': None,
        'experiment': None,
        'data': {
            'datapre_path': None,
            'dataset_path': None,
            'fraction': 1.0,
        },
        'model': {
            'learning_rate': None,
            'epochs': None,
            'batch_size': None,
            'validation_split': 0.2,
            'layers': None,
            'weights': None,
            'l1': None,
            'early_stopping': None,
            'save_path': None,
            'load_path': None
        }
    }

    # Parse the NN.dat file
    for line in lines:
        if line.strip() and not line.startswith('#'):
            key, value, _ = re.split(r'\s+#\s+', line.strip())
            key = key.strip()
            value = value.strip()

            # Convert values to appropriate types
            if key == 'seed':
                config['seed'] = int(value)
            elif key == 'experiment':
                config['experiment'] = value
            elif key == 'datapre_path':
                config['data']['datapre_path'] = '{}'.format(value)
            elif key == 'dataset_path':
                config['data']['dataset_path'] = '{}'.format(value)
            elif key == 'learning_rate':
                config['model']['learning_rate'] = float(value)
            elif key == 'epochs':
                config['model']['epochs'] = int(value)
            elif key == 'batch_size':
                config['model']['batch_size'] = int(value)
            elif key == 'layers':
                config['model']['layers'] = '{}'.format(str(value))
            elif key == 'weights':
                config['model']['weights'] = value
            elif key == 'l1':
                config['model']['l1'] = float(value)
            elif key == 'early_stopping':
                config['model']['early_stopping'] = value.lower() in ['true', '1', 'yes']
            elif key == 'save_path':
                config['model']['save_path'] = value
            elif key == 'load_path':
                config['model']['load_path'] = value

    # Write the configuration to a YAML file
    with open(output_file, 'w') as yaml_file:
        yaml_file.write(f"seed: {config['seed']}\n")
        yaml_file.write(f"experiment: '{config['experiment']}'\n")

        yaml_file.write("# Data configuration\n")
        yaml_file.write(f"data:\n")
        yaml_file.write(f"  datapre_path: '{config['data']['datapre_path']}'\n")
        yaml_file.write(f"  dataset_path: '{config['data']['dataset_path']}'\n")
        yaml_file.write(f"  fraction: {config['data']['fraction']}\n")
        yaml_file.write("# Configurations for CNN model training\n")
        yaml_file.write(f"model:\n")
        yaml_file.write(f"  learning_rate: {config['model']['learning_rate']}\n")
        yaml_file.write(f"  epochs: {config['model']['epochs']}\n")
        yaml_file.write(f"  batch_size: {config['model']['batch_size']}\n")
        yaml_file.write(f"  validation_split: {config['model']['validation_split']}\n")
        yaml_file.write(f"  layers: {config['model']['layers']}\n")
        yaml_file.write(f"  weights: {config['model']['weights']}\n")
        yaml_file.write(f"  l1: {config['model']['l1']}\n")
        yaml_file.write(f"  early_stopping: {config['model']['early_stopping']}\n")
        yaml_file.write(f"  save_path: '{config['model']['save_path']}'\n")
        yaml_file.write(f"  load_path: '{config['model']['load_path']}'\n")


    print(f"YAML configuration file '{output_file}' has been created.")

'''
input_dir = './../params/NN.dat'
output_dir = './../experiment_0/config.yaml'       
convert_dat_to_yaml(input_dir, output_dir)
'''
