import numpy as np
import openseespy.opensees as ops
from numba import jit
from numba import float64 as f8
from numba import int64 as i8
from numba.types import Tuple as tpl
import random
ops.logFile("error.txt")
#----------------------------------------------------------
# openseesを実行
#----------------------------------------------------------
def elastic_analysis_quad_rebar(n,m,r,ijk,E,poi,thickness,mass,fix,patch_id,theta,thicknesses):
    """Performs elastic analysis of a quadrangular mesh with strain energy calculation.
    Args:
        n: Number of nodes (int).
        m: Number of faces (int).
        r: Node coordinate vertex data (numpy array, shape=(n, 3)).
        ijk: Mesh face with node indices (numpy array, shape=(m, 4)).
        E: Young's modulus (float).
        poi: Poisson's ratio (float).
        thickness: Element thickness (float).
        mass: Mass per unit area (float).
        fix: Fixed node indices (numpy array, shape=(n_fix, 3)).

    Returns:
        u: Nodal displacements (numpy array, shape=(n, 6)).
        sec_f: Element section forces (numpy array, shape=(m, 24)).
        strain_energy: Total strain energy of the structure (float).
    """
    theta = theta
    thicknesses = thicknesses
    if theta is None:
        #theta = [i for i in range(len(list(set(patch_id))))]
        theta = [random.choice([0,15,30,45,60,75]) for i in range(len(list(set(patch_id))))]
        thicknesses = [random.choice([0.15,0.20,0.25,0.30]) for i in range(len(list(set(patch_id))))]
        #theta = [random.choice([0,45,90]) for i in range(len(list(set(patch_id))))]
        #theta = [random.choice([0,30,60,90]) for i in range(len(list(set(patch_id))))]
    else:
        theta = [random.choice(theta) for i in range(len(list(set(patch_id))))]
        thicknesses = [random.choice(thicknesses) for i in range(len(list(set(patch_id))))]
    ops.wipe()
    ops.model('BasicBuilder', '-ndm', 3)

    S_Fy =  379*1e6 # yield strength
    S_E0 =  202.7*1e9 #initial elastic tangent
    S_b  =  0.01 #strain-hardening ratio (ratio between post-yield tangent and initial elastic tangent)
    S_R0  = 18.5
    S_cR1 = 0.925
    S_cR2 = 0.15
    S_params = [S_R0,S_cR1,S_cR2] # parameters to control the transition from elastic to plastic branches. params=[R0,cR1,cR2].


    ##################内部境界の補強梁###################
    #ops.section('ElasticMembranePlateSection',1,E,poi,thickness,mass) #材料の入力
    #print(type(ijk))
    #print(ijk.shape)
    
    ops.nDMaterial('ElasticIsotropic', 1, E, poi, mass)
    ops.uniaxialMaterial('Steel02',2,S_Fy,S_E0,S_b,S_R0,S_cR1,S_cR2)

    # need to get number of regions *******************
    for i in list(set(patch_id)):

        prefix = (i+1)*100
        ops.nDMaterial('PlateRebar',int(prefix+10),2,90.0 + theta[i])
        ops.nDMaterial('PlateRebar',int(prefix+11),2,0.0 + theta[i])
        #print(int(prefix+10))
        #print(int(prefix+11))
    # SECTION
    n_layer = int(5)
    concret_outer = 0.05
    # S_Diameter_upper = 0.00953 # D10 Diameter 0.00953 m, Area 0.7133 cm2
    # S_Diameter_lower = 0.00953 # D10 Diameter 0.00953 m, Area 0.7133 cm2#0.019 # D19 Diameter 0.019 m, Area 2.865 cm2
    min_dept = 0.15
    S_Diameter_upper = 0.0075*min_dept
    S_Diameter_lower = 0.0075*min_dept

    for i in list(set(patch_id)):
        prefix = (i+1)*100
        #print(int(i+1))
        #print(int(prefix+10))
        #print(int(prefix+11))
        #print(thickness)
        #print(thickness-(2*concret_outer+S_Diameter_lower+S_Diameter_upper))
        ops.section('LayeredShell',int(i+1),n_layer,1,concret_outer,int(prefix+10),S_Diameter_lower,1,thicknesses[i]-(2*concret_outer+S_Diameter_lower+S_Diameter_upper),int(prefix+11),S_Diameter_upper,1,concret_outer) # DOMAIN 1

    #節点の定義
    #print('-----------')
    #print(n)
    for i in range(n):
        ops.node(i+1,r[i,0],r[i,1],r[i,2])
     
    #要素の定義
    #ijk = (ijk + 1).astype(int)
    #print(ijk)
    #print(m)
    for i in range(m):
        # need to get number of regions *******************
        section_tag = int(patch_id[i]+1)
        '''
        print('--------')   
        print(i+1)
        print('Node 1: {}'.format(int(ijk[i][0]+1)))
        print('Node 2: {}'.format(int(ijk[i][1]+1)))
        print('Node 3: {}'.format(int(ijk[i][2]+1)))
        print('Node 4: {}'.format(int(ijk[i][3]+1)))
        '''
        
        ops.element('shellNLDKGQ',i+1,int(ijk[i][0]+1),int(ijk[i][1]+1),int(ijk[i][2]+1),int(ijk[i][3]+1),section_tag)


        # ops.element('ShellMITC4',i+1,int(ijk[i][0]+1),int(ijk[i][1]+1),int(ijk[i][2]+1),int(ijk[i][3]+1),1)




    # FIX NODES
    for j in range(n):
        for i in range(fix.shape[0]):
            if (round(fix[i][0],5) == round(r[j,0],5))and(round(fix[i][1],5) == round(r[j,1],5)):
                ops.fix(j+1,1,1,1,0,0,0) #境界条件の入力
            else:
                ops.fix(j+1,0,0,0,0,0,0) #境界条件の入力

    ops.timeSeries('Constant',1)
    ops.pattern('Plain', 1, 1, '-fact', 1.0)
    total_load=calc_surface_load_quad(n,m,r,np.array(ijk,dtype=np.int64),mass,thickness) #面荷重の等価節点力を足し込み
    for i in range(n):ops.load(i+1,total_load[i,0],total_load[i,1],total_load[i,2],total_load[i,3],total_load[i,4],total_load[i,5])
    #ops.system('BandGen'),ops.numberer('RCM'),ops.constraints('Plain'),ops.algorithm('Linear')
    ops.system('BandGen'),ops.numberer('RCM'),ops.constraints('Plain'),ops.algorithm('Linear')
    ops.integrator('LoadControl', 1.0)
    ops.analysis('Static')

    ops.analyze(1)

    ops.reactions()
    u=np.zeros((n,6),dtype=np.float64)
    #sec_f=np.zeros((m,18),dtype=np.float64) # change from tri-mesh
    sec_f=np.zeros((m,24),dtype=np.float64)
    #節点変位を求める
    for i in range(n):
        u[i,:]=ops.nodeDisp(i+1)
    #要素の断面力を求める
    for e in range(m):
        sec_f[e,:]=ops.eleForce(e+1)


    str_e = calc_strain_energy(n,total_load,u)





    return u,sec_f,str_e,theta, thicknesses

#断面力の計算に必要な関数の定義
def Lmatrix_tri(r1,r2,r3):
    lx,lz=(r2-r1),np.cross(r2-r1,r3-r1)
    lx,lz=lx/np.linalg.norm(lx),lz/np.linalg.norm(lz)
    ly=np.cross(lz,lx)
    return lx,ly,lz
def make_Bp(b1,b2,b3,c1,c2,c3,s):
    Bp=np.zeros((3,6),dtype=np.float64)
    Lx1,Lx2,Lx3=b1/2.0/s,b2/2.0/s,b3/2.0/s
    Ly1,Ly2,Ly3=c1/2.0/s,c2/2.0/s,c3/2.0/s
    Bp[0,0],Bp[0,2],Bp[0,4]=Lx1,Lx2,Lx3
    Bp[1,1],Bp[1,3],Bp[1,5]=Ly1,Ly2,Ly3
    Bp[2,0],Bp[2,1],Bp[2,2],Bp[2,3],Bp[2,4],Bp[2,5]=Ly1,Lx1,Ly2,Lx2,Ly3,Lx3
    return Bp
def make_Bb(b1,b2,b3,c1,c2,c3,s):
    Lx1,Lx2,Lx3=b1/2.0/s,b2/2.0/s,b3/2.0/s
    Ly1,Ly2,Ly3=c1/2.0/s,c2/2.0/s,c3/2.0/s
    N1_L11=np.array([4./3.,2*(b2/3.-b3/3.),2*(c2/3.-c3/3.)])
    N2_L22=np.array([4./3.,2*(b3/3.-b1/3.),2*(c3/3.-c1/3.)])
    N3_L33=np.array([4./3.,2*(b1/3.-b2/3.),2*(c1/3.-c2/3.)])
    N1_L22=np.array([-2./3.,0,0])
    N2_L33=np.array([-2./3.,0,0])
    N3_L11=np.array([-2./3.,0,0])
    N1_L33=np.array([-2./3.,0,0])
    N2_L11=np.array([-2./3.,0,0])
    N3_L22=np.array([-2./3.,0,0])
    N1_L12=np.array([0,-2*b3/3.+(b2-b3)/6.,-2*c3/3.+(c2-c3)/6.])
    N2_L23=np.array([0,-2*b1/3.+(b3-b1)/6.,-2*c1/3.+(c3-c1)/6.])
    N3_L31=np.array([0,-2*b2/3.+(b1-b2)/6.,-2*c2/3.+(c1-c2)/6.])
    N1_L23=np.array([0,(b2-b3)/6.,(c2-c3)/6.])
    N2_L31=np.array([0,(b3-b1)/6.,(c3-c1)/6.])
    N3_L12=np.array([0,(b1-b2)/6.,(c1-c2)/6.])
    N1_L31=np.array([0,2*b2/3.+(b2-b3)/6.,2*c2/3.+(c2-c3)/6.])
    N2_L12=np.array([0,2*b3/3.+(b3-b1)/6.,2*c3/3.+(c3-c1)/6.])
    N3_L23=np.array([0,2*b1/3.+(b1-b2)/6.,2*c1/3.+(c1-c2)/6.])
    N1_xx=np.array([
    Lx1**2*N1_L11[0]+Lx2**2*N1_L22[0]+Lx3**2*N1_L33[0]+2*Lx1*Lx2*N1_L12[0]+2*Lx2*Lx3*N1_L23[0]+2*Lx3*Lx1*N1_L31[0],
    Lx1**2*N1_L11[1]+Lx2**2*N1_L22[1]+Lx3**2*N1_L33[1]+2*Lx1*Lx2*N1_L12[1]+2*Lx2*Lx3*N1_L23[1]+2*Lx3*Lx1*N1_L31[1],
    Lx1**2*N1_L11[2]+Lx2**2*N1_L22[2]+Lx3**2*N1_L33[2]+2*Lx1*Lx2*N1_L12[2]+2*Lx2*Lx3*N1_L23[2]+2*Lx3*Lx1*N1_L31[2]
    ])
    N1_yy=np.array([
    Ly1**2*N1_L11[0]+Ly2**2*N1_L22[0]+Ly3**2*N1_L33[0]+2*Ly1*Ly2*N1_L12[0]+2*Ly2*Ly3*N1_L23[0]+2*Ly3*Ly1*N1_L31[0],
    Ly1**2*N1_L11[1]+Ly2**2*N1_L22[1]+Ly3**2*N1_L33[1]+2*Ly1*Ly2*N1_L12[1]+2*Ly2*Ly3*N1_L23[1]+2*Ly3*Ly1*N1_L31[1],
    Ly1**2*N1_L11[2]+Ly2**2*N1_L22[2]+Ly3**2*N1_L33[2]+2*Ly1*Ly2*N1_L12[2]+2*Ly2*Ly3*N1_L23[2]+2*Ly3*Ly1*N1_L31[2]
    ])
    N1_xy=np.array([
    Lx1*Ly1*N1_L11[0]+Lx2*Ly2*N1_L22[0]+Lx3*Ly3*N1_L33[0]+(Lx1*Ly2+Lx2*Ly1)*N1_L12[0]+(Lx2*Ly3+Lx3*Ly2)*N1_L23[0]+(Lx3*Ly1+Lx1*Ly3)*N1_L31[0],
    Lx1*Ly1*N1_L11[1]+Lx2*Ly2*N1_L22[1]+Lx3*Ly3*N1_L33[1]+(Lx1*Ly2+Lx2*Ly1)*N1_L12[1]+(Lx2*Ly3+Lx3*Ly2)*N1_L23[1]+(Lx3*Ly1+Lx1*Ly3)*N1_L31[1],
    Lx1*Ly1*N1_L11[2]+Lx2*Ly2*N1_L22[2]+Lx3*Ly3*N1_L33[2]+(Lx1*Ly2+Lx2*Ly1)*N1_L12[2]+(Lx2*Ly3+Lx3*Ly2)*N1_L23[2]+(Lx3*Ly1+Lx1*Ly3)*N1_L31[2]
    ])
    N2_xx=np.array([
    Lx2**2*N2_L22[0]+Lx3**2*N2_L33[0]+Lx1**2*N2_L11[0]+2*Lx2*Lx3*N2_L23[0]+2*Lx3*Lx1*N2_L31[0]+2*Lx1*Lx2*N2_L12[0],
    Lx2**2*N2_L22[1]+Lx3**2*N2_L33[1]+Lx1**2*N2_L11[1]+2*Lx2*Lx3*N2_L23[1]+2*Lx3*Lx1*N2_L31[1]+2*Lx1*Lx2*N2_L12[1],
    Lx2**2*N2_L22[2]+Lx3**2*N2_L33[2]+Lx1**2*N2_L11[2]+2*Lx2*Lx3*N2_L23[2]+2*Lx3*Lx1*N2_L31[2]+2*Lx1*Lx2*N2_L12[2]
    ])
    N2_yy=np.array([
    Ly2**2*N2_L22[0]+Ly3**2*N2_L33[0]+Ly1**2*N2_L11[0]+2*Ly2*Ly3*N2_L23[0]+2*Ly3*Ly1*N2_L31[0]+2*Ly1*Ly2*N2_L12[0],
    Ly2**2*N2_L22[1]+Ly3**2*N2_L33[1]+Ly1**2*N2_L11[1]+2*Ly2*Ly3*N2_L23[1]+2*Ly3*Ly1*N2_L31[1]+2*Ly1*Ly2*N2_L12[1],
    Ly2**2*N2_L22[2]+Ly3**2*N2_L33[2]+Ly1**2*N2_L11[2]+2*Ly2*Ly3*N2_L23[2]+2*Ly3*Ly1*N2_L31[2]+2*Ly1*Ly2*N2_L12[2]
    ])
    N2_xy=np.array([
    Lx2*Ly2*N2_L22[0]+Lx3*Ly3*N2_L33[0]+Lx1*Ly1*N2_L11[0]+(Lx2*Ly3+Lx3*Ly2)*N2_L23[0]+(Lx3*Ly1+Lx1*Ly3)*N2_L31[0]+(Lx1*Ly2+Lx2*Ly1)*N2_L12[0],
    Lx2*Ly2*N2_L22[1]+Lx3*Ly3*N2_L33[1]+Lx1*Ly1*N2_L11[1]+(Lx2*Ly3+Lx3*Ly2)*N2_L23[1]+(Lx3*Ly1+Lx1*Ly3)*N2_L31[1]+(Lx1*Ly2+Lx2*Ly1)*N2_L12[1],
    Lx2*Ly2*N2_L22[2]+Lx3*Ly3*N2_L33[2]+Lx1*Ly1*N2_L11[2]+(Lx2*Ly3+Lx3*Ly2)*N2_L23[2]+(Lx3*Ly1+Lx1*Ly3)*N2_L31[2]+(Lx1*Ly2+Lx2*Ly1)*N2_L12[2]
    ])
    N3_xx=np.array([
    Lx3**2*N3_L33[0]+Lx1**2*N3_L11[0]+Lx2**2*N3_L22[0]+2*Lx3*Lx1*N3_L31[0]+2*Lx1*Lx2*N3_L12[0]+2*Lx2*Lx3*N3_L23[0],
    Lx3**2*N3_L33[1]+Lx1**2*N3_L11[1]+Lx2**2*N3_L22[1]+2*Lx3*Lx1*N3_L31[1]+2*Lx1*Lx2*N3_L12[1]+2*Lx2*Lx3*N3_L23[1],
    Lx3**2*N3_L33[2]+Lx1**2*N3_L11[2]+Lx2**2*N3_L22[2]+2*Lx3*Lx1*N3_L31[2]+2*Lx1*Lx2*N3_L12[2]+2*Lx2*Lx3*N3_L23[2]
    ])
    N3_yy=np.array([
    Ly3**2*N3_L33[0]+Ly1**2*N3_L11[0]+Ly2**2*N3_L22[0]+2*Ly3*Ly1*N3_L31[0]+2*Ly1*Ly2*N3_L12[0]+2*Ly2*Ly3*N3_L23[0],
    Ly3**2*N3_L33[1]+Ly1**2*N3_L11[1]+Ly2**2*N3_L22[1]+2*Ly3*Ly1*N3_L31[1]+2*Ly1*Ly2*N3_L12[1]+2*Ly2*Ly3*N3_L23[1],
    Ly3**2*N3_L33[2]+Ly1**2*N3_L11[2]+Ly2**2*N3_L22[2]+2*Ly3*Ly1*N3_L31[2]+2*Ly1*Ly2*N3_L12[2]+2*Ly2*Ly3*N3_L23[2]
    ])
    N3_xy=np.array([
    Lx3*Ly3*N3_L33[0]+Lx1*Ly1*N3_L11[0]+Lx2*Ly2*N3_L22[0]+(Lx3*Ly1+Lx1*Ly3)*N3_L31[0]+(Lx1*Ly2+Lx2*Ly1)*N3_L12[0]+(Lx2*Ly3+Lx3*Ly2)*N3_L23[0],
    Lx3*Ly3*N3_L33[1]+Lx1*Ly1*N3_L11[1]+Lx2*Ly2*N3_L22[1]+(Lx3*Ly1+Lx1*Ly3)*N3_L31[1]+(Lx1*Ly2+Lx2*Ly1)*N3_L12[1]+(Lx2*Ly3+Lx3*Ly2)*N3_L23[1],
    Lx3*Ly3*N3_L33[2]+Lx1*Ly1*N3_L11[2]+Lx2*Ly2*N3_L22[2]+(Lx3*Ly1+Lx1*Ly3)*N3_L31[2]+(Lx1*Ly2+Lx2*Ly1)*N3_L12[2]+(Lx2*Ly3+Lx3*Ly2)*N3_L23[2]
    ])
    Bb1=np.array([-N1_xx,-N1_yy,-2*N1_xy])
    Bb2=np.array([-N2_xx,-N2_yy,-2*N2_xy])
    Bb3=np.array([-N3_xx,-N3_yy,-2*N3_xy])
    Bb=np.c_[np.c_[Bb1,Bb2],Bb3]
    return Bb
def make_bcs(r1,r2,r3,lx,ly,lz):
    x1,x2,x3=0,np.dot(lx,r2-r1),np.dot(lx,r3-r1)
    y1,y2,y3=0,np.dot(ly,r2-r1),np.dot(ly,r3-r1)
    b1,b2,b3=y2-y3,y3-y1,y1-y2
    c1,c2,c3=x3-x2,x1-x3,x2-x1
    s=0.5*np.linalg.norm(np.cross(r2-r1,r3-r1))
    return b1,b2,b3,c1,c2,c3,s

def make_Dp(e,v):
    Dp=np.array([
    [1,v,0],
    [v,1,0],
    [0,0,(1-v)/2.]
    ])*e/(1-v**2)
    return Dp
def make_Db(e,v,t):
    Db=np.array([
    [1,v,0],
    [v,1,0],
    [0,0,(1-v)/2.]
    ])*e*t**3/12./(1-v**2)
    return Db

def calc_stress(m,u,r,ijk,E,poi,thickness):
    stress=np.zeros((m,4))
    direction=np.zeros((m,12))
    for e in range(m):
        i,j,k=ijk[e][0],ijk[e][1],ijk[e][2]
        u1,u2,u3=u[i],u[j],u[k]
        r1,r2,r3=r[i],r[j],r[k]
        lx,ly,lz=Lmatrix_tri(r1,r2,r3)
        b1,b2,b3,c1,c2,c3,s=make_bcs(r1,r2,r3,lx,ly,lz)
        Bp=make_Bp(b1,b2,b3,c1,c2,c3,s)
        Bb=make_Bb(b1,b2,b3,c1,c2,c3,s)
        Ee,ve,te=E,poi,thickness
        Dp=make_Dp(Ee,ve)
        Db=make_Db(Ee,ve,te)
        L=np.array([
        [lx[0],lx[1],lx[2],0,0,0],
        [ly[0],ly[1],ly[2],0,0,0],
        [lz[0],lz[1],lz[2],0,0,0],
        [0,0,0,lx[0],lx[1],lx[2]],
        [0,0,0,ly[0],ly[1],ly[2]],
        [0,0,0,lz[0],lz[1],lz[2]]
        ])
        u1,u2,u3=np.dot(L,u1),np.dot(L,u2),np.dot(L,u3)#global to local
        dp=np.array([u1[0],u1[1],u2[0],u2[1],u3[0],u3[1]])
        ep=np.dot(Bp,dp)
        sigma_p=np.dot(Dp,ep)
        db=np.array([u1[2],u1[3],u1[4],u2[2],u2[3],u2[4],u3[2],u3[3],u3[4]])
        eb=np.dot(Bb,db)
        sigma_b=np.dot(Db,eb)
        sp_max=(sigma_p[0]+sigma_p[1])/2+np.sqrt(((sigma_p[0]-sigma_p[1])/2)**2+sigma_p[2]**2)
        sp_min=(sigma_p[0]+sigma_p[1])/2-np.sqrt(((sigma_p[0]-sigma_p[1])/2)**2+sigma_p[2]**2)
        theta_p=np.arctan((sp_max-sigma_p[0])/sigma_p[2])
        lp_max,lp_min=np.array([np.cos(theta_p),np.sin(theta_p),0]),np.array([-np.sin(theta_p),np.cos(theta_p),0])
        lp_max,lp_min=np.dot(L[0:3,0:3].T,lp_max),np.dot(L[0:3,0:3].T,lp_min)#local to global

        sb_max=(sigma_b[0]+sigma_b[1])/2+np.sqrt(((sigma_b[0]-sigma_b[1])/2)**2+sigma_b[2]**2)
        sb_min=(sigma_b[0]+sigma_b[1])/2-np.sqrt(((sigma_b[0]-sigma_b[1])/2)**2+sigma_b[2]**2)
        theta_b=np.arctan((sb_max-sigma_b[0])/sigma_b[2])
        lb_max,lb_min=np.array([np.cos(theta_b),np.sin(theta_b),0]),np.array([-np.sin(theta_b),np.cos(theta_b),0])
        lb_max,lb_min=np.dot(L[0:3,0:3].T,lb_max),np.dot(L[0:3,0:3].T,lb_min)#local to global

        stress[e]=sp_max,sp_min,sb_max,sb_min
        direction[e]=lp_max[0],lp_max[1],lp_max[2],lp_min[0],lp_min[1],lp_min[2],lb_max[0],lb_max[1],lb_max[2],lb_min[0],lb_min[1],lb_min[2]
    return stress,direction

#---------------------------------------------------------------------------------
#[calcV_tri]要素体積計算
#---------------------------------------------------------------------------------
def calcV_tri(m,r,ijk,material,thickness):
    V=0.0
    for e in range(m):
        i,j,k=ijk[e,0],ijk[e,1],ijk[e,2]
        ri,rj,rk=r[i],r[j],r[k]
        a,b=rj-ri,rk-ri
        s=0.5*np.sqrt((a[1]*b[2]-a[2]*b[1])**2+(a[2]*b[0]-a[0]*b[2])**2+(a[0]*b[1]-a[1]*b[0])**2)
        V+=s*thickness[material[e]]
    return V

#---------------------------------------------------------------------------------
#[calc_surface_load_tri]
#圧力荷重に対する等価節点力の集計
#---------------------------------------------------------------------------------
def calc_surface_load_quad(n, m, r, ijk, mass, thickness):
    f = np.zeros((n, 6), dtype=np.float64)

    for e in range(m):
        i, j, k, l = ijk[e][0], ijk[e][1], ijk[e][2], ijk[e][3] # Four nodes of the quad element
        ri, rj, rk, rl = r[i], r[j], r[k], r[l] # Coordinates of the four nodes
        p = np.array([0, 0, -thickness * mass * 9.8], dtype=np.float64) # Surface load (downward)

        # Calculate the area of the quad element using cross product of diagonals
        a = rj - ri
        b = rk - rl
        s = np.linalg.norm(np.cross(a, b)) / 2

        # Distribute the load to the nodes
        f[i, 0:3] += p * s / 4
        f[j, 0:3] += p * s / 4
        f[k, 0:3] += p * s / 4
        f[l, 0:3] += p * s / 4

    return f

def calc_surface_load_tri(n,m,r,ijk,mass,thickness):
    f=np.zeros((n,6),dtype=np.float64)
    for e in range(m):
        i,j,k=ijk[e][0],ijk[e][1],ijk[e][2]
        ri,rj,rk,p=r[i],r[j],r[k],np.array([0,0,-thickness*mass*9.8],dtype=np.float64) #面荷重+自重
        a,b=rj-ri,rk-ri
        s=0.5*np.sqrt((a[1]*b[2]-a[2]*b[1])**2+(a[2]*b[0]-a[0]*b[2])**2+(a[0]*b[1]-a[1]*b[0])**2)
        f[i,0:3]+=p*s/3.
        f[j,0:3]+=p*s/3.
        f[k,0:3]+=p*s/3.

    return f

#---------------------------------------------------------------------------------
#[Lmatrix] 座標変換行列
#---------------------------------------------------------------------------------
@jit(tpl((f8[:,:],f8[:]))(f8[:],f8[:],f8[:],f8[:]),nopython=True)
def Lmatrix(r1,r2,r3,r4):
    ex=(r2+r3)/2.0-(r1+r4)/2.0
    ex=ex/np.linalg.norm(ex)
    r21,r41=r2-r1,r4-r1
    ez=np.array([r21[1]*r41[2]-r21[2]*r41[1],r21[2]*r41[0]-r21[0]*r41[2],r21[0]*r41[1]-r21[1]*r41[0]],dtype=np.float64)
    ez=ez/np.linalg.norm(ez)
    ey=np.array([ez[1]*ex[2]-ez[2]*ex[1],ez[2]*ex[0]-ez[0]*ex[2],ez[0]*ex[1]-ez[1]*ex[0]],dtype=np.float64)
    L=np.zeros((3,3),dtype=np.float64)
    L[0,:],L[1,:],L[2,:]=ex,ey,ez
    return L,(r1+r2+r3+r4)/4.0

#---------------------------------------------------------------------------------
#[shape_funcN] 形状関数
#---------------------------------------------------------------------------------
@jit(f8[:](f8,f8),nopython=True)
def shape_funcN(xi,eta):
    N1,N2=(1-xi)*(1-eta)/4.0,(1+xi)*(1-eta)/4.0
    N3,N4=(1+xi)*(1+eta)/4.0,(1-xi)*(1+eta)/4.0
    return np.array([N1,N2,N3,N4],dtype=np.float64)

#---------------------------------------------------------------------------------
#[d_shape_funcN] 形状関数の微分
#---------------------------------------------------------------------------------
@jit(tpl((f8[:],f8[:]))(f8,f8),nopython=True)
def d_shape_funcN(xi,eta):
    N1_xi,N1_eta=-(1-eta)/4.0,-(1-xi)/4.0
    N2_xi,N2_eta=(1-eta)/4.0,-(1+xi)/4.0
    N3_xi,N3_eta=(1+eta)/4.0,(1+xi)/4.0
    N4_xi,N4_eta=-(1+eta)/4.0,(1-xi)/4.0
    return np.array([N1_xi,N2_xi,N3_xi,N4_xi],dtype=np.float64),np.array([N1_eta,N2_eta,N3_eta,N4_eta],dtype=np.float64)

#---------------------------------------------------------------------------------
#[Jacobian]
#---------------------------------------------------------------------------------
@jit(f8[:,:](f8[:],f8[:],f8[:],f8[:],f8[:],f8[:]),nopython=True)
def Jacobian(r1,r2,r3,r4,Ni_xi,Ni_eta):
    L,rc=Lmatrix(r1,r2,r3,r4)
    xi,yi,zi=np.zeros(4,dtype=np.float64),np.zeros(4,dtype=np.float64),np.zeros(4,dtype=np.float64)
    xi[0],yi[0],zi[0]=np.dot(L,r1-rc)
    xi[1],yi[1],zi[1]=np.dot(L,r2-rc)
    xi[2],yi[2],zi[2]=np.dot(L,r3-rc)
    xi[3],yi[3],zi[3]=np.dot(L,r4-rc)
    J=np.zeros((2,2),dtype=np.float64)
    for i in range(4):
        J[0,0]+=Ni_xi[i]*xi[i]
        J[0,1]+=Ni_xi[i]*yi[i]
        J[1,0]+=Ni_eta[i]*xi[i]
        J[1,1]+=Ni_eta[i]*yi[i]
    return J

#---------------------------------------------------------------------------------
#要素等価節点力ベクトル(全体座標系)
#---------------------------------------------------------------------------------
@jit(tpl((f8[:],f8[:],f8[:],f8[:]))(f8[:],f8[:],f8[:],f8[:],f8[:],f8[:],f8[:],f8[:]),nopython=True)
def calc_f(s,gauss_w,gauss_xi,gauss_eta,r1,r2,r3,r4):
    q,f=np.array([s[0],s[1],s[2]],dtype=np.float64),np.zeros(24,dtype=np.float64)
    L,rc=Lmatrix(r1,r2,r3,r4)
    q=np.dot(L,q) #要素座標系に変換
    N=np.zeros(4,dtype=np.float64)
    for beta in range(2):
        for alpha in range(2):
            Ni_xi,Ni_eta=d_shape_funcN(gauss_xi[alpha],gauss_eta[beta])
            J=Jacobian(r1,r2,r3,r4,Ni_xi,Ni_eta)
            Ni=shape_funcN(gauss_xi[alpha],gauss_eta[beta])
            N+=gauss_w[alpha]*gauss_w[beta]*Ni*J[0,0]*J[1,1]
    for i in range(4):f[i*3:i*3+3]=N[i]*q
    for i in range(4):f[i*3:i*3+3]=np.dot(L.T,f[i*3:i*3+3]) #全体座標系に変換
    return f[0:3],f[3:6],f[6:9],f[9:12]

#---------------------------------------------------------------------------------
#[calcV]要素体積計算
#---------------------------------------------------------------------------------
@jit(f8[:](i8,f8[:,:],i8[:,:],i8[:],f8[:]),nopython=True)
def calcV(m,r,ijkl,material,thickness):
    V=np.zeros(m,dtype=np.float64)
    gauss_w=np.ones(2,dtype=np.float64)
    gauss_xi=np.array([-1/np.sqrt(3),1/np.sqrt(3)],dtype=np.float64)
    gauss_eta=np.array([-1/np.sqrt(3),1/np.sqrt(3)],dtype=np.float64)
    for e in range(m):
        i,j,k,l,a=ijkl[e][0],ijkl[e][1],ijkl[e][2],ijkl[e][3],material[e]
        r1,r2,r3,r4,t=r[i,:],r[j,:],r[k,:],r[l,:],thickness[a]
        V[e]=0.0
        for beta in range(2):
            for alpha in range(2):
                Ni_xi,Ni_eta=d_shape_funcN(gauss_xi[alpha],gauss_eta[beta])
                J=Jacobian(r1,r2,r3,r4,Ni_xi,Ni_eta)
                V[e]+=gauss_w[alpha]*gauss_w[beta]*J[0,0]*J[1,1]
        V[e]=V[e]*t
    return V

#---------------------------------------------------------------------------------
#[calc_surface_load]
#圧力荷重に対する等価節点力の集計
#---------------------------------------------------------------------------------
@jit(f8[:,:](i8,i8,f8[:,:],i8[:,:],f8[:,:],i8[:],f8[:],f8[:]),nopython=True)
def calc_surface_load(n,m,r,ijkl,surface_load,material,mass,thickness):
    gauss_w=np.ones(2,dtype=np.float64)
    gauss_xi=np.array([-1/np.sqrt(3),1/np.sqrt(3)],dtype=np.float64)
    gauss_eta=np.array([-1/np.sqrt(3),1/np.sqrt(3)],dtype=np.float64)
    f=np.zeros((n,6),dtype=np.float64)
    for e in range(m):
        i,j,k,l,a=ijkl[e][0],ijkl[e][1],ijkl[e][2],ijkl[e][3],material[e]
        r1,r2,r3,r4,s=r[i,:],r[j,:],r[k,:],r[l,:],surface_load[e]+np.array([0,0,-thickness[a]*mass[a]*9.8],dtype=np.float64) #面荷重+自重
        f1,f2,f3,f4=calc_f(s,gauss_w,gauss_xi,gauss_eta,r1,r2,r3,r4)
        f[i,0:3]+=f1
        f[j,0:3]+=f2
        f[k,0:3]+=f3
        f[l,0:3]+=f4
    return f

#---------------------------------------------------------------------------------
#[calc_strain_energy]
#---------------------------------------------------------------------------------
@jit(f8(i8,f8[:,:],f8[:,:]),nopython=True)
def calc_strain_energy(n,f,u):

    str_e=0.0
    for i in range(n):str_e+=np.dot(f[i],u[i])
    return str_e/2.0

