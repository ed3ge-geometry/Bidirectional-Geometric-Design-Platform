import os
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler, KBinsDiscretizer
import pandas as pd
from scipy import stats
from tqdm import tqdm

def collect_data(base_dir):
    x_data = []
    y_data = []
    num_lines = None

    # Get the list of subfolders named with numbers
    folders = [folder for folder in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, folder)) and folder.isdigit()]

    # Iterate over subfolders with a progress bar
    for folder_name in tqdm(folders, desc="Collecting data"):
        folder_path = os.path.join(base_dir, folder_name)

        theta_file = os.path.join(folder_path, 'data_theta.dat')
        thick_file = os.path.join(folder_path, 'data_thickness.dat')
        max_u_region_file = os.path.join(folder_path, 'data_max_u_region.dat')

        # Check if the required files exist in the subfolder
        if os.path.isfile(theta_file) and os.path.isfile(max_u_region_file):
            # Read data from files
            with open(theta_file, 'r') as f:
                theta_values = [float(line.strip()) for line in f.readlines()]

            with open(thick_file, 'r') as f:
                thick_values = [float(line.strip()) for line in f.readlines()]

            features = [[theta_values[i], thick_values[i]] for i in range(len(thick_values))]
            with open(max_u_region_file, 'r') as f:
                max_u_region_values = [float(line.strip()) for line in f.readlines()]

            # Ensure the files have the same number of lines
            if len(theta_values) == len(max_u_region_values):
                if num_lines is None:
                    num_lines = len(theta_values)
                elif num_lines != len(theta_values):
                    print(f"Warning: File length mismatch in folder {folder_name}")
                    continue

                x_data.append(features)
                y_data.append(max_u_region_values)
            else:
                print(f"Warning: File length mismatch in folder {folder_name}")

    return np.array(x_data), np.array(y_data)

def save_to_npz(x_data, y_data, output_file):
    # Save the data to a .npz file
    np.savez(output_file, x=x_data, y=y_data)
    print(f"Data saved to {output_file}. Shapes - x: {x_data.shape}, y: {y_data.shape}")

def load_from_npz(input_file):
    # Load the data from a .npz file
    with np.load(input_file) as data:
        x_data = data['x']
        y_data = data['y']
    print(f"Data loaded from {input_file}. Shapes - x: {x_data.shape}, y: {y_data.shape}")
    return x_data, y_data


# Load data from the .npz file
def load_dataset(npz_file):
    with np.load(npz_file) as data:
        x_data = data['x']
        y_data = data['y']
    print(f"Data loaded from {npz_file}. Shapes - x: {x_data.shape}, y: {y_data.shape}")
    return x_data, y_data


# Apply Box-Cox transformation to make data Gaussian
def boxcox_transform(y_scaled):
    transformed_data = {}
    for i in range(y_scaled.shape[1]):
        # Ensure data is positive for Box-Cox
        y_col = y_scaled[:, i] - y_scaled[:, i].min() + 1e-9
        transformed_data[f"Domain {i}"], _ = stats.boxcox(y_col)
    transformed_df = pd.DataFrame(transformed_data)
    return transformed_df.to_numpy()


def preprocess2theta(directory,fraction):
    x, y = load_dataset(directory)
    

    # Min-Max Scale the data
    scaler_y = None
    scaler_x = None  # Placeholder if you plan to scale x in the future

    x_scaled = x  # Assuming no scaling is applied to x
    #y = boxcox_transform(y)
    #y_scaled = MinMaxScaler().fit_transform(StandardScaler().fit_transform(y))#scaler_y.fit_transform(y)

    x1 = x[:,:,0] # theta
    x2 = x[:,:,1] # thickness


    # -----------------------------------------------------------------------------------------------------
    # Discretize y
    #n_bins = 1000
    #discretizer = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
    #y_discretized = discretizer.fit_transform(y).astype(int)
    y_discretized = MinMaxScaler().fit_transform(y)#MinMaxScaler().fit_transform(y_discretized)
    # -----------------------------------------------------------------------------------------------------
    thick_nrom = MinMaxScaler().fit_transform(x2)

    combined_array = np.stack((y_discretized, thick_nrom), axis=2)

    return x1, combined_array, scaler_x, scaler_y, y


def preprocess2thick(directory,fraction):
    x, y = load_dataset(directory)
    

    # Min-Max Scale the data
    scaler_y = None
    scaler_x = None  # Placeholder if you plan to scale x in the future

    x_scaled = x  # Assuming no scaling is applied to x
    #y = boxcox_transform(y)
    #y_scaled = MinMaxScaler().fit_transform(StandardScaler().fit_transform(y))#scaler_y.fit_transform(y)

    x1 = x[:,:,0] # theta
    x2 = x[:,:,1] # thickness


    # -----------------------------------------------------------------------------------------------------
    # Discretize y
    #n_bins = 1000
    #discretizer = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
    #y_discretized = discretizer.fit_transform(y).astype(int)
    y_discretized = MinMaxScaler().fit_transform(y)#MinMaxScaler().fit_transform(y_discretized)
    # -----------------------------------------------------------------------------------------------------
    theta_nrom = MinMaxScaler().fit_transform(x1)

    combined_array = np.stack((y_discretized, theta_nrom), axis=2)

    return x2, combined_array, scaler_x, scaler_y, y 



def preprocess(directory,fraction):
    x, y = load_dataset(directory)
    

    # Min-Max Scale the data
    scaler_y = None
    scaler_x = None  # Placeholder if you plan to scale x in the future

    x_scaled = x  # Assuming no scaling is applied to x
    #y = boxcox_transform(y)
    #y_scaled = MinMaxScaler().fit_transform(StandardScaler().fit_transform(y))#scaler_y.fit_transform(y)

    x1 = x[:,:,0] # theta
    x2 = x[:,:,1] # thickness


    # -----------------------------------------------------------------------------------------------------
    # Discretize y
    #n_bins = 1000
    #discretizer = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
    #y_discretized = discretizer.fit_transform(y).astype(int)
    y_discretized = MinMaxScaler().fit_transform(y)#MinMaxScaler().fit_transform(y_discretized)
    # -----------------------------------------------------------------------------------------------------
    thick_nrom = MinMaxScaler().fit_transform(x2)

    combined_array = np.stack((y_discretized, thick_nrom), axis=2)

    return x1, combined_array, scaler_x, scaler_y

def preprocess_pretrain(directory, predirectory, fraction=1.0):
    x, y = load_dataset(directory)
    
    pre_x, pre_y = load_dataset(predirectory)


    # Combine the arrays
    x_combined = np.concatenate((x, pre_x), axis=0)
    y_combined = np.concatenate((y, pre_y), axis=0)

    # Verify the shapes
    print("Combined shapes - x: {}, y: {}".format(x_combined.shape, y_combined.shape))



    global_min_y = np.min(pre_y)
    global_max_y = np.max(pre_y)
    # Determine the number of samples to use based on the fraction
    n_samples = int(len(x) * fraction)
    x = x[:n_samples]
    y = y[:n_samples]

    # Min-Max Scale the data using statistics from pre_y
    scaler_y = MinMaxScaler()
    scaler_y.fit(y_combined)  # Fit the scaler using pre_y
    
    y_scaled = scaler_y.transform(y)  # Transform y using the fitted scaler
    
    scaler_x = None  # Placeholder if you plan to scale x in the future
    x_scaled = x  # Assuming no scaling is applied to x
    
    return x_scaled, y_scaled, scaler_x, scaler_y, global_min_y, global_max_y


def scaler_preprocess2theta(directory ,fraction):
    x, y = load_dataset(directory)
    

    # Min-Max Scale the data
    scaler_y = None
    scaler_x = None  # Placeholder if you plan to scale x in the future

    x_scaled = x  # Assuming no scaling is applied to x
    #y = boxcox_transform(y)
    #y_scaled = MinMaxScaler().fit_transform(StandardScaler().fit_transform(y))#scaler_y.fit_transform(y)

    x1 = x[:,:,0] # theta
    x2 = x[:,:,1] # thickness

    scaler_U = MinMaxScaler()
    scaler_thick = MinMaxScaler()
    
    scaler_U.fit(y)  
    scaler_thick.fit(x2)  
    
    y_discretized = MinMaxScaler().fit_transform(y)#MinMaxScaler().fit_transform(y_discretized)
    # -----------------------------------------------------------------------------------------------------
    thick_nrom = MinMaxScaler().fit_transform(x2)

    combined_array = np.stack((y_discretized, thick_nrom), axis=2)

    return x1, combined_array, scaler_U, scaler_thick


def scaler_preprocess2thick(directory,fraction):
    x, y = load_dataset(directory)
    

    # Min-Max Scale the data
    scaler_y = None
    scaler_x = None  # Placeholder if you plan to scale x in the future

    x_scaled = x  # Assuming no scaling is applied to x
    #y = boxcox_transform(y)
    #y_scaled = MinMaxScaler().fit_transform(StandardScaler().fit_transform(y))#scaler_y.fit_transform(y)

    x1 = x[:,:,0] # theta
    x2 = x[:,:,1] # thickness


    # -----------------------------------------------------------------------------------------------------
    # Discretize y
    #n_bins = 1000
    #discretizer = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
    #y_discretized = discretizer.fit_transform(y).astype(int)
    y_discretized = MinMaxScaler().fit_transform(y)#MinMaxScaler().fit_transform(y_discretized)
    # -----------------------------------------------------------------------------------------------------
    theta_nrom = MinMaxScaler().fit_transform(x1)

    scaler_U = MinMaxScaler()
    scaler_theta = MinMaxScaler()
    
    scaler_U.fit(y)  
    scaler_theta.fit(x1)  

    combined_array = np.stack((y_discretized, theta_nrom), axis=2)

    return x2, combined_array, scaler_U, scaler_theta