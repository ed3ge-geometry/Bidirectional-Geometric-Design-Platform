import openseespy.opensees as op
import numpy as np
import util.fem as fem


from tqdm import tqdm
import numpy as np
import numpy.ma as ma
import random
from pydoc import locate
import igl
import time
import datetime
from scipy.spatial import distance_matrix
from copy import deepcopy
import math
import os
from os.path import exists
import datetime
from io import StringIO
import ast

now_ML = str(datetime.datetime.now().strftime('_%Y-%m-%d_%H_%M_%S'))
def extract_number(filename):
    return int(filename.split('x_step')[1].split('.dat')[0])

def QuadShell_FEM(input_folder, output_folder, data_idx, tList=None, dList=None):
    # format input .dat into numpy array
    vert_init = np.loadtxt(input_folder+'/vertex.dat')#np.loadtxt(input_folder+"/x_steps/x_step{}.dat".format(step))
    vert_fix = np.loadtxt(input_folder+'/fix.dat')#np.loadtxt(input_folder+"/fix.dat")
    #print(vert_init)
    #print(vert_fix)

    # List of line indices to read (assuming 0-based index after skipping the first line)
    lines_to_read = [int(num) for num in vert_fix]
    #print(lines_to_read)
    # Initialize an empty list to store the desired lines
    selected_lines = []

    # Open the file and read lines selectively
    with open(input_folder+'/vertex.dat') as file:
        for i, line in enumerate(file):
            if (i) in lines_to_read:  # Adjust for the skipped first line
                selected_lines.append(line)

    # Convert the selected lines to a single string for np.loadtxt
    selected_lines = selected_lines[1:]
    selected_lines_str = ''.join(selected_lines)
    vert_fix = np.loadtxt(StringIO(selected_lines_str))
    #print(vert_fix)
    face = np.loadtxt(input_folder+"/face.dat")#np.loadtxt(shared_folder+"/face.dat")
    # hyperparam
    vals = [None,None,None,None] # thickness, poi, mass, E
    with open(input_folder+"/hyperparams_structoptim.dat") as openingfile:
        counter = 0
        for line in openingfile:
            l = line.split('#')
            vals[counter] = float(l[1])
            counter += 1
    num_nodes = vert_init.shape[0]
    num_faces = face.shape[0]
    #print(num_nodes)


    region_id = list(np.loadtxt(input_folder+'/region.dat'))
    patch_id = [int(val) for val in region_id]
    u,sec_f,str_e,theta, thicknesses = fem.elastic_analysis_quad_rebar(num_nodes,num_faces,vert_init,face,vals[3],vals[1],vals[0],vals[2], vert_fix, patch_id, tList, dList)
    # save response
    max_u_region = [0 for i in range(len(list(set(patch_id))))]
    for i in range(face.shape[0]):
        node_idx = [int(idx) for idx in face[i]]
        region_no = patch_id[i]
        uz = [abs(u[idx][3]) for idx in node_idx]
        max_u_region[region_no] = max(max_u_region[region_no],max(uz))

    if not os.path.exists(output_folder+'/{}'.format(data_idx)):
        os.makedirs(output_folder+'/{}'.format(data_idx))
    np.savetxt(output_folder+'/{}/u.dat'.format(data_idx),u)
    np.savetxt(output_folder+'/{}/sec_f.dat'.format(data_idx),sec_f)
    np.savetxt(output_folder+'/{}/str_e.dat'.format(data_idx),np.array([str_e]))

    np.savetxt(output_folder+'/{}/data_thickness.dat'.format(data_idx),thicknesses)
    np.savetxt(output_folder+'/{}/data_theta.dat'.format(data_idx),theta)
    np.savetxt(output_folder+'/{}/data_max_u_region.dat'.format(data_idx),max_u_region)
    # print maximum
    maxux=min(u[:,0])
    maxuy=min(u[:,1])
    maxuz=min(u[:,2])
    indexx=np.where(u[:,0]==maxux)
    indexy=np.where(u[:,1]==maxuy)
    indexz=np.where(u[:,2]==maxuz)



    return maxuz,str_e


vals = []

with open("./params/GenOptim.dat") as openingfile:
    for line in openingfile:
        l = line.split('#')
        vals.append((l[1]))
directory = str(vals[0])[1:-1]
tList = ast.literal_eval(str(vals[1][1:-1]))
dList = ast.literal_eval(str(vals[2][1:-1]))




input_folder  = './shell_inputs'
output_folder = directory

maxuz, str_e = QuadShell_FEM(input_folder, output_folder, 0, tList, dList)
