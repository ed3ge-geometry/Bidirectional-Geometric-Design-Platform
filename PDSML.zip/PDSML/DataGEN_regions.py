import numpy as np
import matplotlib.pyplot as plt


def find_boundary_indices(array):
    bnd_indices = np.argwhere(array == 1)
    bnd_x = np.unique(bnd_indices[:, 1])
    bnd_y = np.unique(bnd_indices[:, 0])
    return bnd_x, bnd_y

def assign_regions(array, bnd_x, bnd_y):
    regions = np.zeros_like(array, dtype=int)
    region_counter = 0

    for i in range(len(bnd_y) + 1):
        for j in range(len(bnd_x) + 1):
            x_start = bnd_x[j-1] if j > 0 else 0
            x_end = bnd_x[j] if j < len(bnd_x) else array.shape[1]
            y_start = bnd_y[i-1] if i > 0 else 0
            y_end = bnd_y[i] if i < len(bnd_y) else array.shape[0]

            regions[y_start:y_end, x_start:x_end] = region_counter
            region_counter += 1

    return regions


def read_vertex_file(shell_inputs_directory):

    vertices_filename   = shell_inputs_directory+'/vertex.dat'
    bnd_filename        = shell_inputs_directory+'/bnd.dat'
    output_file         = shell_inputs_directory+'/region.dat'

    with open(vertices_filename, 'r') as f:
        lines = f.readlines()
    rows, cols = map(int, lines[0].split())
    vertices = [list(map(float, line.split())) for line in lines[1:]]
    for vertice in vertices:
          vertice = [round(val) for val in vertice]

    with open(bnd_filename, 'r') as f:
        lines = f.readlines()
    bnd_indices = [int(line.strip()) for line in lines]

    #print(rows)
    #print(cols)
    grid = np.zeros((rows, cols))
    grid_anchor = np.zeros((rows, cols))
    col_idx = 0
    row_idx = 0
    for i in range(len(vertices)):
        if i in bnd_indices:
            #print(i)
            grid_anchor[col_idx][row_idx] = 1
        grid[col_idx][row_idx] = i
        #print(i)
        #print(grid)
        col_idx += 1
        if col_idx == rows:
            col_idx = 0
            row_idx += 1




    x_map = list(set([round(val[0]) for val in vertices]))
    y_map = list(set([round(val[1],2) for val in vertices]))

    # Find the boundary indices
    bnd_x, bnd_y = find_boundary_indices(grid_anchor)

    # Assign regions to the array
    regions = assign_regions(grid_anchor, bnd_x, bnd_y)
    regions = regions[:-1,:-1]


    #output_file = './region.dat'
    with open(output_file, 'w') as f:
        for val in regions.T.reshape(-1,1):
            f.write(f"{val[0]}\n")


    #print(vertices)
    return rows, cols, vertices

def plot_regions(vertices, faces, face_regions):
    regions = np.unique(face_regions)
    colors = plt.cm.get_cmap('tab10', len(regions))

    fig, ax = plt.subplots()

    for i, face in enumerate(faces):
        region = face_regions[i]
        polygon = [vertices[node] for node in face]
        polygon.append(vertices[face[0]])  # Close the polygon
        xs, ys, _ = zip(*polygon)
        ax.fill(xs, ys, color=colors(region), label=f'Region {region}' if region not in ax.get_legend_handles_labels()[1] else "")

    ax.legend(loc='best')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Mesh Regions')
    plt.show()
