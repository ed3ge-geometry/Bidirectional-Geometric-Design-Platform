from util.dat2yaml import convert_dat_to_yaml
import shutil


import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.utils import check_random_state
from sklearn.utils import check_random_state, compute_class_weight
import random
import matplotlib.pyplot as plt
import time
import os
import yaml
import sys

# Add the parent directory to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)


input_dir = './params/NN.dat'
output_dir = './experiment_0/config.yaml'       
convert_dat_to_yaml(input_dir, output_dir)

def load_config(config_file):
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    return config

# LOAD CONFIG
output_path     = './experiment_0/config.yaml'
config = load_config(output_path)



# LOAD ML
def main(config):

    # SET SEED
    SEED_NO = config['seed']
    np.random.seed(SEED_NO)
    random.seed(SEED_NO)
    tf.random.set_seed(SEED_NO)
    rng = check_random_state(SEED_NO)


    # LOAD DATA SET
    from util.process import load_dataset, boxcox_transform, preprocess2theta
   
    datadir = config['data']['dataset_path']
    predatadir = config['data']['datapre_path']
    
    print(datadir)


    X, y, scaler_x, scaler_y, y_init = preprocess2theta(datadir, fraction=1.0) # load and normalized data
    fraction = config['data']['fraction']
    
    # write max u file
    u_path = './experiment_0/u.dat'
    min_values = np.min(y_init, axis=0)
    max_values = np.max(y_init, axis=0)
    # Check if file exists and delete if it does
    if os.path.exists(u_path):
        os.remove(u_path)

    # Write the min and max values to the file
    with open(u_path, 'w') as f:
        for min_val, max_val in zip(min_values, max_values):
            f.write(f"{min_val} {max_val}\n")
 

    
    #print(y)
    # One-hot encode y
    num_classes = 6  # since the discrete values are (0, 15, 30, 45, 60, 75, 90), we have 7 classes
    print("X shape:", X.shape)
    print("y shape:", y.shape)
    X = np.array([tf.keras.utils.to_categorical(label // 15, num_classes) for label in X.reshape(-1)]).reshape(X.shape[0], X.shape[1], num_classes)
    # PREPARE TRAIN-TEST
    # THIS PART x become y and y become x
    print("X shape:", X.shape)
    print("y shape:", y.shape)
    X_train, X_test, y_train, y_test = train_test_split(y, X, test_size=0.1, random_state=SEED_NO, shuffle=True)
    print("X_train shape:", X_train.shape)
    print("X_test shape:", X_test.shape)
    print("y_train shape:", y_train.shape)
    print("y_test shape:", y_test.shape)
    
    # USE ONLY SMALL FRACTION FOR TRAINING
    n_samples = int(len(X_train) * fraction)
    print(n_samples)
    X_train = X_train[:n_samples]
    y_train = y_train[:n_samples]
    print("FRACTION")
    print("X_train shape:", X_train.shape)
    print("X_test shape:", X_test.shape)
    print("y_train shape:", y_train.shape)
    print("y_test shape:", y_test.shape)

    # Compute class weights
    class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train.reshape(-1))
    class_weights = dict(enumerate(class_weights))

    # Create an instance of the CNN model
    from models.model import NN_predictive, weighted_loss
    nn_model = NN_predictive(input_shape=X_train.shape[1:], output_shape=y_train.shape[1:], 
                              learning_rate=config['model']['learning_rate'],
                              layers=config['model']['layers'], 
                              weights=config['model']['weights'], 
                              l1_lambda=config['model']['l1'])

    nn_model.model.summary()
    
    # Load pretrain model
    load_path = os.path.join(os.getcwd(), './models/'+config['model']['load_path'])
    print(load_path)
    try:
        nn_model.load_model_weights(load_path)
        print('LOAD ML MODEL SUCCESS')
    except:
        print('NO PRE-TRAINED MODEL')
    '''
    def finetune_specific_layers(model, layer_names):
        # Set all layers to non-trainable
        for layer in model.layers:
            layer.trainable = False
        
        # Set specific layers to trainable
        for layer_name in layer_names:
            model.get_layer(layer_name).trainable = True

        return model

    # Fine-tune only dense_5 and dense_6 layers
    layer_names_to_train = ['dense_4']
    nn_model.model = finetune_specific_layers(nn_model.model, layer_names_to_train)
    nn_model.model.summary()

    # Compile the model after modifying trainable layers
    nn_model.model.compile(optimizer=tf.keras.optimizers.RMSprop(learning_rate=nn_model.learning_rate), 
                           loss=weighted_loss, 
                           metrics=['accuracy'])
    '''
    # Train the model
    start_time = time.time()
    if config['model']['early_stopping']:
        early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)
        callbacks = [early_stopping]
    else:
        callbacks = None
    tensorboard_dir = os.path.join(os.getcwd(), './experiment_'+config['experiment']+'/logs')

    nn_model.train(X_train, y_train, epochs=config['model']['epochs'], batch_size=config['model']['batch_size'],
                    validation_split=config['model']['validation_split'], callbacks=callbacks,
                    tensorboard_dir=tensorboard_dir, class_weight=class_weights)

    end_time = time.time()
    execution_time = end_time - start_time
    print("Train time:", execution_time, "seconds")

    # Save model weights
    save_path = config['model']['save_path']
    nn_model.save_model_weights('./experiment_'+config['experiment']+'/'+save_path)
    print("Model weights saved to:", save_path)

    from sklearn.metrics import precision_score, recall_score
    
    # Evaluate the model on the test data
    loss, accuracy = nn_model.model.evaluate(X_test, y_test)
    print("Loss on test data:", loss)
    print("Accuracy on test data:", accuracy)

    # Make predictions
    y_pred_prob = nn_model.model.predict(X_test)

    # Apply custom decision threshold (assuming a threshold of -1, which means no thresholding)
    #threshold = -1
    #y_pred = (y_pred_prob >= threshold).astype(int)

    # Ensure only one class is selected (if needed)
    y_pred = (y_pred_prob == y_pred_prob.max(axis=2, keepdims=True))
    #print(y_pred)
    # Compute predicted values for each domain
    y_pred_vals = []
    for domain_idx in range(y_pred.shape[1]):  # Iterate over each domain index
        y_pred_domain = np.argmax(y_pred[:, domain_idx, :], axis=-1) * 15  # Shape: (num_samples,)
        y_pred_vals.append(y_pred_domain)

    y_pred_vals = np.stack(y_pred_vals, axis=1)  # Shape: (num_samples, num_domains)
    #print(y_pred_vals)
    # Convert y_true and y_pred_vals to numpy arrays
    y_true = np.argmax(y_test, axis=-1) * 15  # Convert back to original discrete values
    #print(y_true)
    # Initialize lists to store precision and recall for each domain
    precision_per_domain = []
    recall_per_domain = []

    # Calculate precision and recall for each domain
    for domain_idx in range(y_true.shape[1]):  # Assuming y_true and y_pred_vals are of shape (num_samples, num_domains)
        y_true_domain = y_true[:, domain_idx]
        y_pred_domain = y_pred_vals[:, domain_idx]

        precision = precision_score(y_true_domain, y_pred_domain, average='macro', zero_division=1)
        recall = recall_score(y_true_domain, y_pred_domain, average='macro', zero_division=1)

        precision_per_domain.append(precision)
        recall_per_domain.append(recall)

    # Calculate errors
    errors = []
    for true_vals, pred_vals in zip(y_true, y_pred_vals):
        error = abs((true_vals - pred_vals) * 100 / 75)
        errors.append(error)
    error = np.array(errors)

    # Log the metrics
    log_file = './experiment_'+config['experiment']+"/02_log.txt"
    if os.path.exists(log_file):
        os.remove(log_file)
    with open(log_file, "a") as f:
        for i in range(error.shape[1]):
            print('GRID NO. {}'.format(i))
            data = error[:,i]
            max_error = np.max(data, axis=0)
            avg_error = np.mean(data, axis=0)
            med_error = np.median(data, axis=0)
            min_error = np.min(data, axis=0)
            std_error = np.std(data, axis=0)
            
            print('maximum error {}'.format(max_error))
            print('average error {}'.format(avg_error))
            print('median error {}'.format(med_error))
            print('minimum error {}'.format(min_error))
            print('std.    error {}'.format(std_error))
            print('-------------------------------')
            
            f.write('GRID NO. {}\n'.format(i))
            f.write('maximum error {}\n'.format(max_error))
            f.write('average error {}\n'.format(avg_error))
            f.write('median error {}\n'.format(med_error))
            f.write('minimum error {}\n'.format(min_error))
            f.write('std.    error {}\n'.format(std_error))
            f.write('-------------------------------\n')

            # Plotting error distribution for the current grid
            plt.figure(figsize=(10, 6))
            plt.hist(data, bins=20, range=(0, 100), alpha=0.75, edgecolor='black')
            plt.title(f'Error Distribution for GRID NO. {i}')
            plt.xlabel('Error')
            plt.ylabel('Frequency')
            plt.xlim(0, 100)
            plt.grid(True)
            plt.savefig('./experiment_'+config['experiment']+'/error_distribution_grid_{}.png'.format(i))
            plt.close()
        
        # Log precision and recall for each domain
        for domain_idx, (p, r) in enumerate(zip(precision_per_domain, recall_per_domain)):
            print('Domain {}: Precision = {}, Recall = {}'.format(domain_idx, p, r))
            f.write('Domain {}: Precision = {}, Recall = {}\n'.format(domain_idx, p, r))
        f.write('-------------------------------\n')

    # Overall precision and recall (macro-averaging across all domains)
    overall_precision = np.mean(precision_per_domain)
    overall_recall = np.mean(recall_per_domain)
    print('Overall Precision = {}'.format(overall_precision))
    print('Overall Recall = {}'.format(overall_recall))
    with open(log_file, "a") as f:
        f.write('Overall Precision = {}\n'.format(overall_precision))
        f.write('Overall Recall = {}\n'.format(overall_recall))
        f.write('-------------------------------\n')


    # Plot history
    if os.path.exists('./experiment_'+config['experiment']+'/loss_history.png'):
        os.remove('./experiment_'+config['experiment']+'/loss_history.png')
    nn_model.plot_loss_history('./experiment_'+config['experiment']+'/loss_history.png')