from util.dat2yaml import convert_dat_to_yaml
import os
import shutil
from experiment_0.main import main, load_config

import sys

# Add the parent directory to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

# WRITE YAML FILE
input_dir = './params/NN.dat'
output_dir = './experiment_0/config.yaml'       
convert_dat_to_yaml(input_dir, output_dir)

# RUN AS MASTER
config = load_config(output_dir)
main(config)
print('DONE TRAINING NN')
