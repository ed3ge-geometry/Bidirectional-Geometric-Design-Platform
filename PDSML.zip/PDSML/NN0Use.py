
import shutil
import ast

import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.utils import check_random_state
from sklearn.utils import check_random_state, compute_class_weight
import random
import matplotlib.pyplot as plt
import time
import os
import yaml
import sys

'''
TO DO
1. Get Input U
2. Get Limit U
3. If u > limit : u= limit
4. Get Input thickness
5. Get configuration of NN and data
6. Normailze U and thickness
7. Run NN inference
8. Save results
'''

# Get Input U / Get Limit U / Get Input thickness / Get configuration of NN and data
vals = []
with open("./params/NN0use.dat") as openingfile:
    for line in openingfile:
        l = line.split('#')
        vals.append((l[1]))


inputU = ast.literal_eval(str(vals[0][1:-1]))
limU = float(vals[1])
inputT = ast.literal_eval(str(vals[2][1:-1]))
config_path = str(vals[3][1:-1])
weight_path = str(vals[4][1:-1])

def load_config(config_file):
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    return config

# LOAD CONFIG
config = load_config(config_path)


# If u > limit : u= limit
constraint_inputU = [min(limU,val) for val in inputU]




# LOAD ML
def main(config):

    # SET SEED
    SEED_NO = config['seed']
    np.random.seed(SEED_NO)
    random.seed(SEED_NO)
    tf.random.set_seed(SEED_NO)
    rng = check_random_state(SEED_NO)


    # LOAD DATA SET
    from util.process import load_dataset, boxcox_transform, scaler_preprocess2theta
   
    datadir = config['data']['dataset_path']
    #predatadir = config['data']['datapre_path']
    
  

    X, y, scaler_U, scaler_t = scaler_preprocess2theta(datadir, fraction=1.0) # load and normalized data
    U = np.array(constraint_inputU).reshape(1,-1)
    t = np.array(inputT).reshape(1,-1)

    norm_U = scaler_U.transform(U)
    norm_t = scaler_t.transform(t)

    
    
    fraction = config['data']['fraction']
    
    
    # This are just for initialize the model
    # One-hot encode y
    num_classes = 6  # since the discrete values are (0, 15, 30, 45, 60, 75, 90), we have 7 classes
    X = np.array([tf.keras.utils.to_categorical(label // 15, num_classes) for label in X.reshape(-1)]).reshape(X.shape[0], X.shape[1], num_classes)
    X_train, X_test, y_train, y_test = train_test_split(y, X, test_size=0.1, random_state=SEED_NO, shuffle=True)
    # Compute class weights
    class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train.reshape(-1))
    class_weights = dict(enumerate(class_weights))

    # Create an instance of the CNN model
    from models.model import NN_predictive, weighted_loss
    nn_model = NN_predictive(input_shape=X_train.shape[1:], output_shape=y_train.shape[1:], 
                              learning_rate=config['model']['learning_rate'],
                              layers=config['model']['layers'], 
                              weights=config['model']['weights'], 
                              l1_lambda=config['model']['l1'])

    nn_model.model.summary()
    
    # Load pretrain model
    load_path = weight_path

    try:
        nn_model.load_model_weights(load_path)
        print('LOAD ML MODEL SUCCESS')
    except:
        print('NO PRE-TRAINED MODEL')

    combined_input = np.stack((norm_U, norm_t), axis=2)

    y_pred_prob = nn_model.model.predict([combined_input])
    y_pred = (y_pred_prob == y_pred_prob.max(axis=2, keepdims=True))
    y_pred_vals = []
    for domain_idx in range(y_pred.shape[1]):  # Iterate over each domain index
        y_pred_domain = np.argmax(y_pred[:, domain_idx, :], axis=-1) * 15  # Shape: (num_samples,)
        y_pred_vals.append(y_pred_domain)

    y_pred_vals = np.stack(y_pred_vals, axis=1)  # Shape: (num_samples, num_domains)
    

    # Log the metrics
    log_file = './experiment_'+config['experiment']+"/03_prediction.txt"
    if os.path.exists(log_file):
        os.remove(log_file)
    with open(log_file, "a") as f:
        f.write('{}\n'.format(list(y_pred_vals[0])))
    print('Suggested Rebar Directions {}\n'.format(y_pred_vals[0]))


main(config)
print('FINISH PREDICTION')