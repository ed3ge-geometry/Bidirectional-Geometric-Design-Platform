from util.process import collect_data, save_to_npz, load_from_npz
import os
import shutil
# INPUT
vals = []
with open("./params/Gen.dat") as openingfile:
    for line in openingfile:
        l = line.split('#')
        vals.append((l[1]))
directory = str(vals[0])[1:-1]
base_directory = directory

# OUTPUT
dataset = './dataset'
if not os.path.exists(dataset):
    os.makedirs(dataset)
output_npz = dataset+'/dataset.npz'

# Collect data from the directories
x_collected, y_collected = collect_data(base_directory)

# Save the collected data to a .npz file
save_to_npz(x_collected, y_collected, output_npz)
print('SAVE DATA SUCCESS')

# Load the data from the .npz file
x_loaded, y_loaded = load_from_npz(output_npz)
print('LOAD DATA SUCCESS')

# Delete base directory
try:
    shutil.rmtree(base_directory)
    print(f'Deleted base directory: {base_directory}')
except Exception as e:
    print(f'Error deleting base directory: {e}')


