import numpy as np
import tensorflow as tf
import random
import matplotlib.pyplot as plt
import time
import os
from tensorflow.keras.regularizers import l1, l2

def weighted_loss(y_true, y_pred):
    # Convert predictions back to original discrete values for each domain
    y_pred_vals = []
    for domain_idx in range(y_pred.shape[1]):  # Iterate over each domain index
        y_pred_domain = tf.argmax(y_pred[:, domain_idx, :], axis=-1) * 15  # Shape: (batch_size,)
        y_pred_vals.append(y_pred_domain)
    
    # Stack predictions across domains
    y_pred_val = tf.stack(y_pred_vals, axis=1)  # Shape: (batch_size, num_domains)
    #tf.print("y_pred_val:", y_pred_val)

    # Convert true values back to original discrete values
    y_true_val = tf.argmax(y_true, axis=-1) * 15
    #tf.print("y_true_val:", y_true_val)
    
    # Cast to float32 for operations
    y_pred_val = tf.cast(y_pred_val, tf.float32)
    y_true_val = tf.cast(y_true_val, tf.float32)
    
    # Calculate weights based on absolute error normalized by maximum possible error (90)
    # weights = tf.abs(y_true_val - y_pred_val) / 90.0

    # Calculate absolute error
    absolute_error = tf.abs(y_true_val - y_pred_val)/ 90.0
    #tf.print("absolute_error:", absolute_error)
    #print('========')
    #defined_large = 0.5
    #large_error = tf.math.maximum(0.0,absolute_error-defined_large)*10.0
    # Nonlinear transformation of error
    # You can choose a nonlinear function based on your preference
    weighted_error = tf.pow(1.5, absolute_error)  # Example: Nonlinear transformation (power of 1.5)
    
    # Introduce a threshold-based penalization for large errors
    threshold = 0.2  # This can be adjusted based on your needs
    large_error_penalty = tf.where(absolute_error > threshold, tf.pow(3.0, absolute_error), 0.0)  # Penalize errors above the threshold
    
    # Combine the weighted error and the large error penalty
    combined_error = weighted_error + large_error_penalty

    # Normalize by maximum possible error (90)
    weights = combined_error 

    
    # Calculate categorical cross-entropy loss
    loss = tf.keras.losses.categorical_crossentropy(y_true, y_pred)
    
    # Apply the weights
    weighted_loss = loss 
    
    # Return the mean loss across the batch
    return tf.reduce_mean(weighted_loss)


class NN_predictive:
    def __init__(self, input_shape, output_shape, learning_rate=0.001, layers=None, weights=None, l1_lambda=0.01):
        self.input_shape = input_shape
        self.output_shape = output_shape
        self.learning_rate = learning_rate
        self.layers = layers
        self.weights = weights if weights is not None else ['glorot_uniform'] * len(layers)
        self.l1_lambda = l1_lambda

        if self.layers is None:
            raise ValueError("Please provide the 'layers' parameter specifying the number of features in each layer.")
        
        if len(self.layers) != len(self.weights):
            raise ValueError("Length of 'layers' and 'weights' parameters must be the same.")
        
        self.model = self.build_model()
        optimizer = tf.keras.optimizers.Adam(learning_rate=self.learning_rate)
        self.model.compile(loss=tf.keras.losses.categorical_crossentropy, optimizer=optimizer,metrics=['accuracy'])
        self.history = {'loss': [], 'accuracy': [], 'val_loss': [], 'val_accuracy': []}

    
    def build_model(self):
        
        # Modify the input layer to accept shape (8, 2)
        input_layer = tf.keras.Input(shape=(self.input_shape[0], 2))
        
        # Split the input into two separate tensors
        branch1_input = tf.keras.layers.Lambda(lambda x: x[:, :, 0])(input_layer)
        branch2_input = tf.keras.layers.Lambda(lambda x: x[:, :, 1])(input_layer)
        
        branch1_input = tf.keras.layers.Dense(self.layers[0], kernel_initializer=self.weights[0], kernel_regularizer=l2(self.l1_lambda))(branch1_input)
        branch1_input = tf.keras.layers.BatchNormalization()(branch1_input)
        branch1_input = tf.keras.layers.LeakyReLU(alpha=0.02)(branch1_input)
        
        branch2_input = tf.keras.layers.Dense(self.layers[0], kernel_initializer=self.weights[0], kernel_regularizer=l2(self.l1_lambda))(branch2_input)
        branch2_input = tf.keras.layers.BatchNormalization()(branch2_input)
        branch2_input = tf.keras.layers.LeakyReLU(alpha=0.02)(branch2_input)

        x = tf.keras.layers.Concatenate()([branch1_input, branch2_input]) 

        for i in range(len(self.layers)-1):
            residual = x
            x = tf.keras.layers.Dense(self.layers[i+1], kernel_initializer=self.weights[i+1],kernel_regularizer=l2(self.l1_lambda))(x)
            x = tf.keras.layers.BatchNormalization()(x)
            #x = tf.keras.activations.sigmoid(x)
            #x = tf.keras.layers.add([residual, x])  # Residual connection
            
            x = tf.keras.layers.LeakyReLU(alpha=0.02)(x)
            x = tf.keras.layers.Dropout(0.3)(x)
            x = tf.keras.layers.Concatenate()([residual, x])  # Residual connection
	    
        # Output layer for multi-class classification
        x = tf.keras.layers.Dense(128,kernel_regularizer=l2(self.l1_lambda))(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.LeakyReLU(alpha=0.02)(x)
        x = tf.keras.layers.Dropout(0.3)(x)
        
        x = tf.keras.layers.Dense(64,kernel_regularizer=l2(self.l1_lambda))(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.LeakyReLU(alpha=0.02)(x)
        x = tf.keras.layers.Dropout(0.3)(x)
        
        output_layer = tf.keras.layers.Dense(np.prod(self.output_shape), activation='softmax')(x)
        output_layer = tf.keras.layers.Reshape(self.output_shape)(output_layer)
        
        model = tf.keras.Model(inputs=input_layer, outputs=output_layer)
        return model
    

    def train(self, X_train, y_train, epochs=100, batch_size=32, validation_split=0.2, callbacks=None, tensorboard_dir=None, class_weight=None):
        if callbacks is None:
            callbacks = []

        if tensorboard_dir:
            tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=tensorboard_dir, histogram_freq=1)
            callbacks.append(tensorboard_callback)

        # Early stopping and learning rate reduction on plateau
        early_stopping_callback = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=50, restore_best_weights=True)
        reduce_lr_callback = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=10, min_lr=1e-8)

        callbacks.extend([reduce_lr_callback])

        # Convert y_train to the sum of grid values for each sample
        #y_train_sum = np.sum(y_train, axis=(1, 2, 3))
        

        history = self.model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=validation_split, verbose=1, callbacks=callbacks, class_weight=None)
        self.history['loss'] = history.history['loss']
        self.history['val_loss'] = history.history['val_loss']
        self.history['accuracy'] = history.history['accuracy']
        self.history['val_accuracy'] = history.history['val_accuracy']


    def predict(self, X_test):
        return self.model.predict(X_test)

    def save_model_weights(self, filepath):
        self.model.save_weights(filepath)

    def load_model_weights(self, filepath):
        self.model.load_weights(filepath)

    def plot_loss_history(self,filepath):
        plt.plot(self.history['loss'], label='Training Loss')
        plt.plot(self.history['val_loss'], label='Validation Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.title('Training and Validation Loss')
        #plt.yscale('log')  # Set y-axis to log scale
        plt.legend()
        plt.savefig(filepath)
        plt.close()  # Close the plot to release resources 
    def plot_val_history(self,filepath):
        plt.plot(self.history['accuracy'], label='Training Accuracy')
        plt.plot(self.history['val_accuracy'], label='Validation Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.title('Training and Validation Accuracy')
        #plt.yscale('log')  # Set y-axis to log scale
        plt.legend()
        plt.savefig(filepath)
        plt.close()  # Close the plot to release resources 

