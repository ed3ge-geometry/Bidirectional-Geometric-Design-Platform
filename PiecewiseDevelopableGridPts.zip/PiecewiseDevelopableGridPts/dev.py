"""
Form Generation of Piecewise Developable Surface with Grid Points
(K. Hayakawa et al., JIASS, 2023.9)

Major Parameters
vert_ini :: intial coordinates of grid points
vert_dev :: optimal coordinates of grid points
aa_ini   :: intial sum of squared areas of Gauss map
aa_dev   :: optimal sum of squared areas of Gauss map
ni       :: number of grid points in i-direction
nj       :: number of grid points in j-direction
fix      :: indices of grid points whose locations are fixed
bnd      :: indices of grid points whose square of areas are neglected
nhv      :: indices of neighborhood grid points for all interior points
idv      :: indices of interior grid points for all interior points
nhdev    :: indices of neighborhood grid points whose areas of gauss map are minimized
idev     :: indices of interior grid points whose areas of gauss map are minimized
movev    :: indices of grid points whose z-coordinates veries in form genetation
dzmin    :: min. value of changes of z-coordinates of grid points
dzmax    :: max. value of changes of z-coordinates of grid points
"""

import numpy as np
from scipy import optimize



# ---------------------------------------------
# data type converter
def dtype_convert(input_string):
    try:
        out = float(input_string)
    except ValueError:
        out = str(input_string)
        if out.lower() == 'true':
            out = True
        elif out.lower() == 'false':
            out = False
        elif out.lower() == 'none':
            out = None
    return out

# read input data from files
def data_input_dev(vertfile, fixfile, bndfile, paramfile):
    # grid points
    with open(vertfile) as f:
        ndata = f.readline()
    ndata = ndata.split(' ')
    ni = int(ndata[0].strip())
    nj = int(ndata[1].strip())
    vert = np.loadtxt(vertfile, dtype=float, skiprows=(1))
    # fixed grid points
    fix = np.loadtxt(fixfile, dtype=int)
    # grid points whose z-cooridnates will vary in optimization
    bnd = np.loadtxt(bndfile, dtype=int)
    # range of variable z-coordinates
    with open(paramfile) as file:
        hp = dict()
        for line in file:
            l = line.split(':')
            hp[l[0].strip()] = dtype_convert(l[1].strip())
    dzmin = hp['dzmin_dev']
    dzmax = hp['dzmax_dev']
    ftol = hp['ftol']
    if isinstance(dzmin, float) == False:
        dzmin = None
    if isinstance(dzmax, float) == False:
        dzmax = None
    if isinstance(dzmax, float) == False:
        ftol = 1.e-8
    return vert, ni, nj, fix, bnd, dzmin, dzmax, ftol

# construct datas for optimization
def const_grid(ni, nj, fix, bnd):
    # neighborhood grid points and internal grid points
    nhv = np.zeros((0,8),int)
    iv = np.zeros(0,int)
    for j in range(1,nj-1):
        for i in range(1,ni-1):
            iv = np.append(iv, i+ni*j)
            nhv = np.append(nhv, np.zeros((1,8),int), axis=0)
            nhv[-1,0] = (i-1)+ni*(j-1)
            nhv[-1,1] = (i-1)+ni*j
            nhv[-1,2] = (i-1)+ni*(j+1)
            nhv[-1,3] = i+ni*(j+1)
            nhv[-1,4] = (i+1)+ni*(j+1)
            nhv[-1,5] = (i+1)+ni*j
            nhv[-1,6] = (i+1)+ni*(j-1)
            nhv[-1,7] = i+ni*(j-1)
    # consideration of the specified internal boundary
    nhdev = np.zeros((0,8),int)
    idev = np.zeros(0,int)
    for i in range(len(iv)):
        if iv[i] not in bnd:
            idev = np.append(idev, iv[i])
            nhdev = np.append(nhdev, [nhv[i]], axis=0)
    # indices of vertices whese z-coordinates vary in the optimization
    movev = np.delete(np.arange(ni*nj), fix)
    return nhv, iv, nhdev, idev, movev



# ---------------------------------------------
# calculation of square of area of gauss map
def area2(vert, nhv, iv):
    aa = np.zeros(len(iv))          # square of area of gauss map
    norm = np.zeros((len(iv),8,3))  # unit normals of faces
    n0 = iv
    for i in range(8):
        n1 = nhv[:,i]
        n2 = nhv[:,(i+1)%8]
        v1 = vert[n1]-vert[n0]
        v2 = vert[n2]-vert[n0]
        norm2 = np.cross(v1,v2, axis=1)
        norm[:,i,:] = norm2/np.linalg.norm(norm2, axis=1).reshape([len(iv),1])
    norm0 = np.average(norm, axis=1)  # normal vector at interior vetices
    for i in range(8):
        f1 = i
        f2 = (i+1)%8
        v1 = norm[:,f1,:]-norm0
        v2 = norm[:,f2,:]-norm0
        vv = np.cross(v1,v2, axis=1)
        aa += np.sum(vv*vv, axis=1)/4.0
    return aa

# calculation of sensitivity of square of area of gauss map
def darea2(vert, nhv, iv):
    daa = np.zeros((len(iv),vert.shape[0])) # sensitivity of square of area of gauss map
    norm = np.zeros((len(iv),8,3))    # unit normals of faces
    dnorm0 = np.zeros((len(iv),8,3))  # sensitivity of unit normals of faces
    dnorm1 = np.zeros((len(iv),8,3))  # sensitivity of unit normals of faces
    dnorm2 = np.zeros((len(iv),8,3))  # sensitivity of unit normals of faces
    n0 = iv
    dv10 = np.tile(np.array([0.,0.,-1.]), (len(iv),1))
    dv11 = np.tile(np.array([0.,0.,1.]), (len(iv),1))
    dv20 = np.tile(np.array([0.,0.,-1.]), (len(iv),1))
    dv22 = np.tile(np.array([0.,0.,1.]), (len(iv),1))
    for i in range(8):
        n1 = nhv[:,i]
        n2 = nhv[:,(i+1)%8]
        v1 = vert[n1]-vert[n0]
        v2 = vert[n2]-vert[n0]
        norm2 = np.cross(v1,v2, axis=1)
        dnorm20 = np.cross(dv10,v2, axis=1) + np.cross(v1,dv20, axis=1)
        dnorm21 = np.cross(dv11,v2, axis=1)
        dnorm22 = np.cross(v1,dv22, axis=1)
        anorm2 = np.linalg.norm(norm2, axis=1).reshape([len(iv),1])
        norm[:,i,:] = norm2/anorm2
        danorm20 = np.sum(norm2*dnorm20, axis=1).reshape([len(iv),1])/anorm2
        danorm21 = np.sum(norm2*dnorm21, axis=1).reshape([len(iv),1])/anorm2
        danorm22 = np.sum(norm2*dnorm22, axis=1).reshape([len(iv),1])/anorm2
        dnorm0[:,i,:] = (anorm2*dnorm20-danorm20*norm2)/anorm2**2
        dnorm1[:,i,:] = (anorm2*dnorm21-danorm21*norm2)/anorm2**2
        dnorm2[:,i,:] = (anorm2*dnorm22-danorm22*norm2)/anorm2**2
    norm0 = np.average(norm,axis=1)
    dnorm00 = np.average(dnorm0,axis=1)
    dnorm01 = np.average(dnorm1,axis=1)
    dnorm02 = np.average(dnorm2,axis=1)
    ii = np.arange(len(iv))
    for i in range(8):
        f1 = i
        f2 = (i+1)%8
        f3 = (i+2)%8
        v1 = norm[:,f1,:]-norm0
        dv10 = dnorm0[:,f1,:]-dnorm00
        dv11 = dnorm1[:,f1,:]-dnorm01
        dv12 = dnorm2[:,f1,:]-dnorm02
        v2 = norm[:,f2,:]-norm0
        dv20 = dnorm0[:,f2,:]-dnorm00
        dv21 = dnorm1[:,f2,:]-dnorm01
        dv22 = dnorm2[:,f2,:]-dnorm02
        vv = np.cross(v1,v2, axis=1)
        dvv0 = np.cross(dv10,v2, axis=1) + np.cross(v1,dv20, axis=1)
        dvv1 = np.cross(dv11,v2, axis=1)
        dvv2 = np.cross(dv12,v2, axis=1) + np.cross(v1,dv21, axis=1)
        dvv3 = np.cross(v1,dv22, axis=1)
        davv0 = np.sum(vv*dvv0, axis=1)/2.0
        davv1 = np.sum(vv*dvv1, axis=1)/2.0
        davv2 = np.sum(vv*dvv2, axis=1)/2.0
        davv3 = np.sum(vv*dvv3, axis=1)/2.0
        n1 = nhv[:,i]
        n2 = nhv[:,(i+1)%8]
        n3 = nhv[:,(i+2)%8]
        daa[ii,n0] += davv0
        daa[ii,n1] += davv1
        daa[ii,n2] += davv2
        daa[ii,n3] += davv3
    return daa



# ---------------------------------------------
# objective function
def objfunc(x, vert, movev, nhdev, idev):
    global objdev
    vert_c = np.copy(vert)
    vert_c[movev,2] = x
    aa = area2(vert_c, nhdev, idev)
    obj = np.sum(aa)
    objdev = np.copy(obj)
    return obj

# gradient of objective function
def objgrad(x, vert, movev, nhdev, idev):
    vert_c = np.copy(vert)
    vert_c[movev,2] = x
    daa0 = darea2(vert_c, nhdev, idev)
    daa = daa0[:,movev]
    dobj = np.sum(daa, axis=0)
    return dobj

# callback function
def callback(x):
    global objdev, itrdev
    itrdev += 1
    print('%i  %.5e' % (itrdev, objdev))

# solve optimization problem
def piecewise_develop(vert, movev, nhdev, idev,
                      dzmin=None, dzmax=None, dzr=0.2,
                      ftol=1.e-8, iprint=False, maxiter=1000):
    global objdev, itrdev
    # initialize variable
    x = vert[movev,2]
    # range of variable (z-coordinates of grid points)
    if dzmin == None:
        dzmin = -dzr*(np.max(vert[:,2]) - np.min(vert[:,2]))
    if dzmax == None:
        dzmax = dzr*(np.max(vert[:,2]) - np.min(vert[:,2]))
    bounds = np.zeros((len(x),2))
    bounds[:,0] = x + dzmin
    bounds[:,1] = x + dzmax
    # solve optimization problem
    if iprint:
        sol = optimize.minimize(objfunc, x,
                                args=(vert, movev, nhdev, idev),
                                method='SLSQP', jac=objgrad,
                                bounds=bounds, callback=callback,
                                options=({'maxiter': maxiter, 'ftol':ftol}))
        print(sol.message)
    else:
        sol = optimize.minimize(objfunc, x,
                                args=(vert, movev, nhdev, idev),
                                method='SLSQP', jac=objgrad,
                                bounds=bounds, options=({'maxiter': maxiter, 'ftol':ftol}))
    # result
    vert_dev = np.copy(vert)
    vert_dev[movev,2] = sol.x
    return vert_dev



# ---------------------------------------------
# main part
if __name__ == '__main__':

    # file names
    vertfile='vertex.dat'
    fixfile='fix.dat'
    bndfile='bnd.dat'
    paramfile='hyperparams.dat'
    areafile_ini='aa_ini.dat'
    areafile_dev='aa_dev.dat'

    # read input data
    vert_ini, ni, nj, fix, bnd, dzmin, dzmax, ftol = \
    data_input_dev(vertfile, fixfile, bndfile, paramfile)

    # construct datas for optimization
    nhv, iv, nhdev, idev, movev = const_grid(ni, nj, fix, bnd)

    # compute initial squared area of Gauss map
    aa_ini = area2(vert_ini, nhv, iv)
    aa_iniall = np.zeros(vert_ini.shape[0])
    aa_iniall[iv] += aa_ini
    np.savetxt(areafile_ini, aa_iniall, fmt='%.8e')

    # compute initial velue of objective function
    objdev = np.sum(aa_ini)

    # optimization
    itrdev = 0
    vert_dev = piecewise_develop(vert_ini, movev, nhdev, idev, dzmin, dzmax, ftol, iprint=True, maxiter=5000)

    # output result
    with open(vertfile, 'w') as f:
        f.write('%i %i\n'%(ni, nj))
        for i in range(vert_dev.shape[0]):
            f.write('%.16e %.16e %.16e\n'%(vert_dev[i,0], vert_dev[i,1], vert_dev[i,2]))

    # compute optimal squared area of Gauss map
    aa_dev = area2(vert_dev, nhv, iv)
    aa_devall = np.zeros(vert_dev.shape[0])
    aa_devall[iv] += aa_dev
    np.savetxt(areafile_dev, aa_devall, fmt='%.8e')
