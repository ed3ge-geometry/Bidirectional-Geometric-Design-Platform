import numpy as np
import os
import shutil
import time

##################################################

class Cahn_Hoffman:

    def __init__(self, normal, param, st0=np.zeros((2,0)), nsample=100, maxitr=100, eps=1.e-10, iprint=False):
        # normal vector for computing Cahn-Hoffman map
        self.__nn = normal
        # parameters in Gielis's formula
        self.__k1 = param[0]
        self.__k2 = param[1]
        self.__l1 = param[2]
        self.__m1 = param[3]
        self.__k3 = param[4]
        self.__k4 = param[5]
        self.__l2 = param[6]
        self.__m2 = param[7]
        self.__a = param[8]
        self.__b = param[9]
        self.__c = param[10]
        # set initial guess of (s,t) coordinates
        if st0.shape[1] == 0:
            st_sample, gamma_sample, nn_sample = self.sampling(nsample)
            self.st = np.zeros((2,normal.shape[1]))
            self.gamma = np.zeros(normal.shape[1])
            for i in range(normal.shape[1]):
                cc = np.abs(1. - np.dot(normal[:,i], nn_sample))
                self.st[:,i] = st_sample[:,np.argmin(cc)]
                self.gamma[i] = gamma_sample[np.argmin(cc)]
        else:
            self.st = st0
            self.gamma = np.linalg.norm(self.wulff(st), axis=0)
        # maximum number of iteration in Newton-Raphson method
        self.__maxitr = maxitr
        # stopping criteria of Newton-Raphson method
        self.__eps = eps
        # print process of Newton-Raphson method or not
        self.__iprint = iprint
        # identify (s,t) coordinate and gamma
        self.newton_raphson()
        # reidentify if gamma is negative
        while np.min(self.gamma) < 0:
            nsample *= 2
            st_sample, gamma_sample, nn_sample = self.sampling(nsample)
            self.st = np.zeros((2,normal.shape[1]))
            self.gamma = np.zeros(normal.shape[1])
            for i in range(normal.shape[1]):
                cc = np.abs(1. - np.dot(normal[:,i], nn_sample))
                self.st[:,i] = st_sample[:,np.argmin(cc)]
                self.gamma[i] = gamma_sample[np.argmin(cc)]
            self.newton_raphson()
        # compute Cahn-Hoffman map
        try:
            self.xi = self.cahn_hoffman_map()
        except:
            self.xi = self.cahn_hoffman_map2()

    # radius in Gielis's formula
    @staticmethod
    def radius(t, ka, kb, l, m):
        return ((np.cos(m*t/4.)**2)**ka + (np.sin(m*t/4.)**2)**kb)**(-0.5/l)

    @staticmethod
    def diffradius(t, ka, kb, l, m):
        dr = m/l/4.
        dr *= ka*np.cos(m*t/4.)**(2*ka-1)*np.sin(m*t/4.) - kb*np.sin(m*t/4.)**(2*kb-1)*np.cos(m*t/4.)
        dr /= ((np.cos(m*t/4.)**2)**ka + (np.sin(m*t/4.)**2)**kb)**(1+0.5/l)
        return dr

    # point on Wulff shape that defines gamma
    def wulff(self, st):
        rs = self.radius(st[0], self.__k1, self.__k2, self.__l1, self.__m1)
        rt = self.radius(st[1], self.__k3, self.__k4, self.__l2, self.__m2)
        x = (self.__a + rs*rt*np.sin(st[0])*np.sin(st[1])).reshape([1, st.shape[1]])
        y = (self.__b - rs*rt*np.sin(st[0])*np.cos(st[1])).reshape([1, st.shape[1]])
        z = (self.__c - rs*np.cos(st[0])).reshape([1, st.shape[1]])
        pt = np.vstack((x, y, z))
        return pt

    def diffwulff(self, st):
        rs = self.radius(st[0], self.__k1, self.__k2, self.__l1, self.__m1)
        rt = self.radius(st[1], self.__k3, self.__k4, self.__l2, self.__m2)
        drs = self.diffradius(st[0], self.__k1, self.__k2, self.__l1, self.__m1)
        drt = self.diffradius(st[1], self.__k3, self.__k4, self.__l2, self.__m2)
        dx_s = (drs*rt*np.sin(st[0])*np.sin(st[1]) + rs*rt*np.cos(st[0])*np.sin(st[1])).reshape([1, st.shape[1]])
        dy_s = (-drs*rt*np.sin(st[0])*np.cos(st[1]) - rs*rt*np.cos(st[0])*np.cos(st[1])).reshape([1, st.shape[1]])
        dz_s = (-drs*np.cos(st[0]) + rs*np.sin(st[0])).reshape([1, st.shape[1]])
        dpt_s = np.vstack((dx_s, dy_s, dz_s))
        dx_t = (rs*drt*np.sin(st[0])*np.sin(st[1]) + rs*rt*np.sin(st[0])*np.cos(st[1])).reshape([1, st.shape[1]])
        dy_t = (-rs*drt*np.sin(st[0])*np.cos(st[1]) + rs*rt*np.sin(st[0])*np.sin(st[1])).reshape([1, st.shape[1]])
        dz_t = np.zeros((1, st.shape[1]))
        dpt_t = np.vstack((dx_t, dy_t, dz_t))
        return dpt_s, dpt_t

    # sampling (s,t) coordinates
    def sampling(self, nsample):
        s_sample = np.repeat(np.arange(nsample+1)/nsample, nsample+1)*np.pi
        t_sample = np.tile(np.arange(nsample+1)/nsample, nsample+1)*np.pi*2.
        st_sample = np.vstack((s_sample.reshape([1,len(s_sample)]), t_sample.reshape([1,len(t_sample)])))
        pt_sample = self.wulff(st_sample)
        gamma_sample = np.linalg.norm(pt_sample, axis=0)
        nn_sample = pt_sample / gamma_sample.reshape([1, pt_sample.shape[1]])
        return st_sample, gamma_sample, nn_sample

    # equations solved in Newton-Raphson method
    def equation(self, st, gamma, nn):
        pt = self.wulff(st)
        eqn = pt - (gamma.reshape([1,len(gamma)]))*nn
        eqn = np.ravel(eqn.T)
        return eqn

    def jacobian(self, st, nn):
        jac = np.zeros((3*st.shape[1], 3*st.shape[1]))
        dpt_s, dpt_t = self.diffwulff(st)
        for i in range(st.shape[1]):
            jac[3*i:3*i+3,3*i] = dpt_s[:,i]
            jac[3*i:3*i+3,3*i+1] = dpt_t[:,i]
            jac[3*i:3*i+3,3*i+2] = -nn[:,i]
        return jac

    # Newton-Raphson method
    def newton_raphson(self):
        # evaluate initial errors of equations to be solved
        eqn0 = self.equation(self.st, self.gamma, self.__nn)
        # start iteration
        for itr in range(self.__maxitr):
            # evaluate errors
            eqn = self.equation(self.st, self.gamma, self.__nn)
            if self.__iprint:
                print(itr, np.linalg.norm(eqn))
            # stopping criterion 1
            if np.linalg.norm(eqn)/np.linalg.norm(eqn0) < self.__eps:
                break
            # evaluate Jacobian
            jac = self.jacobian(self.st, self.__nn)
            # calculate increment of variable x
            try:
                dx = np.linalg.solve(jac, -eqn)   # Jacobian is non-singular
            except:
                dx, _, _, _ = np.linalg.lstsq(jac, -eqn, rcond=None)   # Jacobian is singular
            # stopping criterion 2
            if np.linalg.norm(dx)/np.sqrt(np.sum(self.st**2)+np.sum(self.gamma**2)) < self.__eps:
                break
            # update variable x
            dx = (dx.reshape([self.__nn.shape[1],3])).T
            self.st += dx[0:2]
            self.gamma += dx[2]

    # Cahn-Hoffman map
    def cahn_hoffman_map(self):
        # points on Wulff shape
        pt = self.wulff(self.st)
        x = pt[0]
        y = pt[1]
        z = pt[2]
        # polar coordinates of points
        w = np.sqrt(x**2 + y**2)
        theta = np.arctan2(z, w)
        rho = np.arctan2(y, x)
        # derivatives of x, y, and z w.r.t. s and t
        dpt_s, dpt_t = self.diffwulff(self.st)
        # determinant of system of pt, dpt_s, and dpt_t
        det = np.sum(pt * np.cross(dpt_s, dpt_t, axis=0), axis=0)
        # compute coefficients in Cahn-Hoffman map
        coef1 = (-dpt_s[0]*dpt_t[1] + dpt_t[0]*dpt_s[1]) * np.cos(theta)
        coef1 += (dpt_t[0]*np.sin(rho) - dpt_t[1]*np.cos(rho)) * dpt_s[2] * np.sin(theta)
        coef1 *= self.gamma**2 / det
        coef2 = -(self.gamma**2 / det) * (dpt_t[0]*np.cos(rho) + dpt_t[1]*np.sin(rho)) * dpt_s[2]
        # compute Cahn-Hoffman map
        xi1x = (coef1 * (-np.sin(theta) * np.cos(rho))).reshape([1, len(theta)])
        xi2x = (coef2 * (-np.cos(theta) * np.sin(rho))).reshape([1, len(theta)])
        xi1y = (coef1 * (-np.sin(theta) * np.sin(rho))).reshape([1, len(theta)])
        xi2y = (coef2 * ( np.cos(theta) * np.cos(rho))).reshape([1, len(theta)])
        xi1z = (coef1 * np.cos(theta)).reshape([1, len(theta)])
        xi2z = np.zeros((1, len(theta)))
        xi1 = np.vstack((xi1x, xi1y, xi1z))
        xi2 = np.vstack((xi2x, xi2y, xi2z))
        xi = xi1 + xi2 + pt
        return xi

    def cahn_hoffman_map2(self):
        # point on Wulff shape
        pt = self.wulff(self.st)
        x = pt[0]
        y = pt[1]
        z = pt[2]
        w = np.sqrt(x**2 + y**2)
        theta = np.arctan(z/w)
        rho = np.arctan2(y, x)
        # radius in Gielis's formula
        rs = self.radius(self.st[0], self.__k1, self.__k2, self.__l1, self.__m1)
        rt = self.radius(self.st[1], self.__k3, self.__k4, self.__l2, self.__m2)
        drs = self.diffradius(self.st[0], self.__k1, self.__k2, self.__l1, self.__m1)
        drt = self.diffradius(self.st[1], self.__k3, self.__k4, self.__l2, self.__m2)
        # derivative of normal vector w.r.t. theta
        dnx_theta = (-np.sin(theta)*np.cos(rho)).reshape([1, len(theta)])
        dny_theta = (-np.sin(theta)*np.sin(rho)).reshape([1, len(theta)])
        dnz_theta = np.cos(theta).reshape([1, len(theta)])
        dnn_theta = np.vstack((dnx_theta, dny_theta, dnz_theta))
        # derivatives of normal vectors w.r.t. theta and rho
        dnx_rho = (-np.cos(theta)*np.sin(rho)).reshape([1, len(rho)])
        dny_rho = (np.cos(theta)*np.cos(rho)).reshape([1, len(rho)])
        dnz_rho = np.zeros((1, len(rho)))
        dnn_rho = np.vstack((dnx_rho, dny_rho, dnz_rho))
        # derivatives of gamma w.r.t. s and t
        dpt_s, dpt_t = self.diffwulff(self.st)
        dgamma_s = np.sum(self.__nn*dpt_s, axis=0)
        dgamma_t = np.sum(self.__nn*dpt_t, axis=0)
        # derivative of theta w.r.t. s
        dtheta_s = (z - self.__c) / z * (drs / rs - np.tan(self.st[0]))
        dtheta_s -= (x * (x - self.__a) + y * (y - self.__b)) / (w**2) * (drs / rs + 1./np.tan(self.st[0]))
        dtheta_s *= z*w / (z**2 + w**2)
        # derivative of theta w.r.t. t
        dtheta_t = x * (x - self.__a) / (w**2) * (drt / rt + 1./np.tan(self.st[1]))
        dtheta_t += y * (y - self.__b) / (w**2) * (drt / rt - np.tan(self.st[1]))
        dtheta_t *= -z*w / (z**2 + w**2)
        # derivative of rho w.r.t. s
        drho_s = (y - self.__b) / y - (x - self.__a) / x
        drho_s *= drs / rs + 1./np.tan(self.st[0])
        drho_s *= x*y / (x**2 + y**2)
        # derivative of rho w.r.t. t
        drho_t = (y - self.__b) / y * (drt / rt - np.tan(self.st[1]))
        drho_t -= (x - self.__a) / x * (drt / rt + 1./np.tan(self.st[1]))
        drho_t *= x*y / (x**2 + y**2)
        # derivatives of s and t w.r.t. theta and rho
        det = dtheta_s * drho_t - dtheta_t * drho_s
        ds_theta = drho_t / det
        ds_rho = -dtheta_t / det
        dt_theta = -drho_s / det
        dt_rho = dtheta_s / det
        # derivetives of gamma w.r.t. theta and rho
        dgamma_theta = dgamma_s * ds_theta + dgamma_t * dt_theta
        dgamma_rho = dgamma_s * ds_rho + dgamma_t * dt_rho
        # compute Cahn-Hoffman map
        xi1 = dnn_theta * dgamma_theta.reshape([1,len(dgamma_theta)])
        xi2 = dnn_rho * (dgamma_rho / np.cos(theta)).reshape([1, len(theta)])
        xi = xi1 + xi2 + pt
        return xi


##################################################

def face_normal(vert, face):
    v1 = vert[:,face[1]] - vert[:,face[0]]
    v2 = vert[:,face[2]] - vert[:,face[0]]
    fnormal = np.cross(v1, v2, axis=0)
    farea = 0.5*np.linalg.norm(fnormal, axis=0)
    fnormal /= 2.*farea.reshape([1, fnormal.shape[1]])
    return fnormal, farea

def camc_flow(vert, face, param, alpha):
    fnormal, area = face_normal(vert, face)
    cf = Cahn_Hoffman(fnormal, param)
    energy = 0.
    flow = np.zeros(vert.shape)
    for i in range(face.shape[1]):
        energy += alpha * cf.gamma[i] * area[i]
        vv = np.dot(vert[:,face[0,i]], np.cross(vert[:,face[1,i]], vert[:,face[2,i]])) / 6
        energy -= vv
        for j in range(3):
            flow[:,face[j,i]] += alpha * 0.5 * np.cross(cf.xi[:,i], vert[:,face[(j+2)%3,i]] - vert[:,face[(j+1)%3,i]])
            flow[:,face[j,i]] -= np.cross(vert[:,face[(j+1)%3,i]], vert[:,face[(j+2)%3,i]]) / 6
    return energy, flow

def srf_evolve(vert, face, free, param, alpha, w0=0.1, beta=0.8, psi=0.2, tau=0.5, nitr=100, outhist=-1):
    # initialize history data
    if outhist > 0:
        if os.path.isdir("./history"):
            shutil.rmtree("./history")
        os.mkdir("./history")
    # output initial data
    energy, flow = camc_flow(vert, face, param, alpha)
    index = 0
    np.savetxt("vertex_out.dat", vert.T)
    if outhist > 0:
        if index%outhist == 0:
            np.savetxt("./history/vertex_%i.dat"%(index), vert.T)
    # surface evolution using nesterov's acceleration
    mome = np.zeros(vert.shape)
    stop_count = 0
    for i in range(1,nitr+1):
        # Nesterov's accelerated gradient discent
        energy0, flow0 = camc_flow(vert, face, param, alpha)
        energy1, flow1 = camc_flow(vert + beta*mome, face, param, alpha)
        for j in range(6):
            w = w0 * (tau**j)
            energy2, flow2 = camc_flow(vert - w*flow0 + beta*mome, face, param, alpha)
            if energy2 <= energy1 + psi * w * np.sum(flow2**2):
                stop_count = 0
                break
            if j == 5:
                stop_count += 1
        if stop_count >= 3:
            break
        mome = beta * mome - w * flow1
        vert[:,free] = vert[:,free] + mome[:,free]
        # result
        energy, flow = camc_flow(vert, face, param, alpha)
        print("%i   E %.3e   moment %.3e"%(i, energy, np.linalg.norm(mome[:,free])))
        # output
        np.savetxt("vertex_out.dat", vert.T)
        if outhist > 0:
            if i%outhist == 0:
                np.savetxt("./history/vertex_%i.dat"%(i), vert.T)


##################################################
if __name__ == '__main__':

    start_time = time.time()

    prm = np.loadtxt("params.dat", dtype=float)
    k1, k2 = prm[0], prm[1]
    k3, k4 = prm[4], prm[5]
    l1, l2 = prm[2], prm[6]
    m1, m2 = int(prm[3]+0.1), int(prm[7]+0.1)
    a, b, c = prm[8], prm[9], prm[10]
    meanc = prm[11]
    nitr = int(prm[12]+0.1)
    outhist = int(prm[13]+0.1)
    param = [k1, k2, l1, m1, k3, k4, l2, m2, a, b, c]


    # get data from input files
    vert = np.loadtxt("vertex.dat", dtype=float).T
    face = np.loadtxt("face.dat", dtype=int).T
    if os.path.isfile("fix.dat"):
        fix = np.loadtxt("fix.dat", dtype=int)
    else:
        fix = np.zeros(0, int)
    free = np.delete(np.arange(vert.shape[1]),np.unique(fix))

    # surface evolve
    alpha = 1. / (2*meanc)
    srf_evolve(vert, face, free, param, alpha, w0=0.1, beta=0.8, psi=0.2, tau=0.5, nitr=nitr, outhist=outhist)

    print("End")
    print('Time: %.5e'%(time.time()-start_time))
