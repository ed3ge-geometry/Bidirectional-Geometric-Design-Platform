import numpy as np

#---------------------------------------------------------
# parameters
rho = 1e0   # density
grav = 1e0  # gravitational acceleration
thick = 1e0 # thickness

# number of nodes
nums = np.loadtxt('division.dat',dtype=int)
ndvu = nums[0]
ndvv = nums[1]

# position of nodes
xy_a = np.loadtxt('vertex.dat')
xx1_a = np.zeros((ndvv+1,ndvu+1))
xx2_a = np.zeros((ndvv+1,ndvu+1))
for j in range(0,ndvu+1):
	for i in range(0,ndvv+1):
		xx1_a[i,j] = xy_a[i+(ndvv+1)*j,0]
		xx2_a[i,j] = xy_a[i+(ndvv+1)*j,1]

# surface derivative
dd_a = np.loadtxt('derivative.dat')

# stress distribution
stress_all = np.loadtxt('stress.dat')
sigma11_a , sigma22_a , sigma12_a = np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
sigma11_1a , sigma22_1a , sigma12_1a = np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
errsig11, errsig22, errsig12=np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
for j in range(0,ndvu+1):
    for i in range(0,ndvv+1):
        sigma11_a[i,j] = stress_all[i+(ndvv+1)*j,0]
        sigma22_a[i,j] = stress_all[i+(ndvv+1)*j,1]
        sigma12_a[i,j] = stress_all[i+(ndvv+1)*j,2]
        sigma11_1a[i,j] = sigma11_a[i,j]
        sigma22_1a[i,j] = sigma22_a[i,j]
        sigma12_1a[i,j] = sigma12_a[i,j]


'''
coefs = np.loadtxt('coefficient.dat')
sigma11_a , sigma22_a , sigma12_a = np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
sigma11_0a , sigma22_0a , sigma12_0a = np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
sigma11_1a , sigma22_1a , sigma12_1a = np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
errsig11, errsig22, errsig12=np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1)),np.zeros((ndvv+1,ndvu+1))
for j in range(0,ndvu+1):
    for i in range(0,ndvv+1):
        sigma12_a[i,j] = coefs[0]*xx1_a[i,j] + coefs[1]*xx2_a[i,j] + coefs[2]
        sigma11_a[i,j] = -coefs[1]*xx1_a[i,j] + coefs[3]*xx2_a[i,j] + coefs[4]
        sigma22_a[i,j] = coefs[5]*xx1_a[i,j] - coefs[0]*xx2_a[i,j] + coefs[6]
        sigma11_0a[i,j] = sigma11_a[i,j]
        sigma22_0a[i,j] = sigma22_a[i,j]
        sigma12_0a[i,j] = sigma12_a[i,j]
        sigma11_1a[i,j] = sigma11_a[i,j]
        sigma22_1a[i,j] = sigma22_a[i,j]
        sigma12_1a[i,j] = sigma12_a[i,j]
'''
fitmin=-0.60
fitmax=0.60
fitmin_err11=0.0
fitmax_err11=0.0
fitmin_err22=0.0
fitmax_err22=0.0
for ii in range(0,ndvv+1):
    if (xx2_a[ii,0] >= fitmin):
        fitmin_err11 = errsig11[ii,0]-(xx2_a[ii,0]-fitmin)/(xx2_a[ii,0]-xx2_a[ii-1,0])*(errsig11[ii,0]-errsig11[ii-1,0])
        break
for ii in range(0,ndvv+1):
    if (xx2_a[ii,0] >= fitmax):
        fitmax_err11 = errsig11[ii,0]-(xx2_a[ii,0]-fitmax)/(xx2_a[ii,0]-xx2_a[ii-1,0])*(errsig11[ii,0]-errsig11[ii-1,0])
        break
for jj in range(0,ndvu+1):
    if (xx1_a[0,jj] >= fitmin):
        fitmin_err22 = errsig22[0,jj]-(xx1_a[0,jj]-fitmin)/(xx1_a[0,jj]-xx1_a[0,jj-1])*(errsig22[0,jj]-errsig22[0,jj-1])
        break
for jj in range(0,ndvu+1):
    if (xx1_a[0,jj] >= fitmax):
        fitmax_err22 = errsig22[0,jj]-(xx1_a[0,jj]-fitmax)/(xx1_a[0,jj]-xx1_a[0,jj-1])*(errsig22[0,jj]-errsig22[0,jj-1])
        break

for j in range(0,ndvu+1):
    for i in range(0,ndvv+1):
        # sigma_x
        if (xx2_a[i,j] <= fitmin):
            sigma11_1a[i,j]=sigma11_1a[i,j]-fitmin_err11
        elif (xx2_a[i,j] >= fitmax):
            sigma11_1a[i,j]=sigma11_1a[i,j]-fitmax_err11
        else:
            Err_s=0
            for ii in range(0,ndvv+1):
                if (xx2_a[ii,0] >= xx2_a[i,j]):
                    Err_s = errsig11[ii,0]-(xx2_a[ii,0]-xx2_a[i,j])/(xx2_a[ii,0]-xx2_a[ii-1,0])*(errsig11[ii,0]-errsig11[ii-1,0])
                    break
            sigma11_1a[i,j] = sigma11_1a[i,j]-Err_s
        # sigma_y
        if (xx1_a[i,j] <= fitmin):
            sigma22_1a[i,j] = sigma22_1a[i,j]-fitmin_err22
        elif (xx1_a[i,j] >= fitmax):
            sigma22_1a[i,j] = sigma22_1a[i,j]-fitmax_err22
        else:
            Err_s=0
            for jj in range(0,ndvu+1):
                if (xx1_a[0,jj] >= xx1_a[i,j]):
                    Err_s = errsig22[0,jj]-(xx1_a[0,jj]-xx1_a[i,j])/(xx1_a[0,jj]-xx1_a[0,jj-1])*(errsig22[0,jj]-errsig22[0,jj-1])
                    break
            sigma22_1a[i,j]=sigma22_1a[i,j]-Err_s
        sigma12_1a[i,j] = sigma12_1a[i,j]
        sigma11_a[i,j] = sigma11_1a[i,j]
        sigma22_a[i,j] = sigma22_1a[i,j]
        sigma12_a[i,j] = sigma12_1a[i,j]

#---------------------------------------------------------
# rearrangement of surface derivatives
dxdu_a = np.zeros((ndvv+1,ndvu+1))
dydu_a = np.zeros((ndvv+1,ndvu+1))
dxdv_a = np.zeros((ndvv+1,ndvu+1))
dydv_a = np.zeros((ndvv+1,ndvu+1))
AAu_a = np.zeros((ndvv+1,ndvu+1))  # d2x_du2
BBu_a = np.zeros((ndvv+1,ndvu+1))  # d2y_du2
CCu_a = np.zeros((ndvv+1,ndvu+1))  # d2x_dvdu
DDu_a = np.zeros((ndvv+1,ndvu+1))  # d2y_dvdu
AAv_a = np.zeros((ndvv+1,ndvu+1))  # d2x_dudv
BBv_a = np.zeros((ndvv+1,ndvu+1))  # d2y_dudv
CCv_a = np.zeros((ndvv+1,ndvu+1))  # d2x_dv2
DDv_a = np.zeros((ndvv+1,ndvu+1))  # d2y_dv2
for j in range(0,ndvu+1):
    for i in range(0,ndvv+1):
        dxdu_a[i,j] = dd_a[i+j*(ndvv+1),0]
        dydu_a[i,j] = dd_a[i+j*(ndvv+1),1]
        dxdv_a[i,j] = dd_a[i+j*(ndvv+1),2]
        dydv_a[i,j] = dd_a[i+j*(ndvv+1),3]
        AAu_a[i,j] = dd_a[i+j*(ndvv+1),4]
        BBu_a[i,j] = dd_a[i+j*(ndvv+1),5]
        CCu_a[i,j] = dd_a[i+j*(ndvv+1),6]
        DDu_a[i,j] = dd_a[i+j*(ndvv+1),7]
        AAv_a[i,j] = dd_a[i+j*(ndvv+1),6]
        BBv_a[i,j] = dd_a[i+j*(ndvv+1),7]
        CCv_a[i,j] = dd_a[i+j*(ndvv+1),8]
        DDv_a[i,j] = dd_a[i+j*(ndvv+1),9]

# area at each node
du = 1. / ndvu
dv = 1. / ndvv
A_a = (dxdu_a * dydv_a - dxdv_a * dydu_a) * du * dv

# inverse of Jacobian matrix
aa_a =  dydv_a / (dxdu_a * dydv_a - dydu_a * dxdv_a)
bb_a = -dydu_a / (dxdu_a * dydv_a - dydu_a * dxdv_a)
cc_a = -dxdv_a / (dxdu_a * dydv_a - dydu_a * dxdv_a)
dd_a =  dxdu_a / (dxdu_a * dydv_a - dydu_a * dxdv_a)

# derivatives of a, b, c, and d
au_a = -(aa_a**2 * AAu_a + aa_a * bb_a * CCu_a + aa_a * cc_a * BBu_a + bb_a * cc_a * DDu_a)
bu_a = -(aa_a * bb_a * AAu_a + bb_a**2 * CCu_a + aa_a * dd_a * BBu_a + bb_a * dd_a * DDu_a)
cu_a = -(aa_a * cc_a * AAu_a + aa_a * dd_a * CCu_a + cc_a**2 * BBu_a + dd_a * cc_a * DDu_a)
du_a = -(bb_a * cc_a * AAu_a + bb_a * dd_a * CCu_a + cc_a * dd_a * BBu_a + dd_a**2 * DDu_a)
av_a = -(aa_a**2 * AAv_a + aa_a * bb_a * CCv_a + aa_a * cc_a * BBv_a + bb_a * cc_a * DDv_a)
bv_a = -(aa_a * bb_a * AAv_a + bb_a**2 * CCv_a + aa_a * dd_a * BBv_a + bb_a * dd_a * DDv_a)
cv_a = -(aa_a * cc_a * AAv_a + aa_a * dd_a * CCv_a + cc_a**2 * BBv_a + dd_a * cc_a * DDv_a)
dv_a = -(bb_a * cc_a * AAv_a + bb_a * dd_a * CCv_a + cc_a * dd_a * BBv_a + dd_a**2 * DDv_a)

# initialize nodal height
new_h_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
dheight1_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
dheight2_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
d2height1_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
d2height2_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
d2height3_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)

# boundary conditions
height_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
Phi_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)
Pz_a = np.zeros((ndvv+1,ndvu+1), dtype=np.float64)

# iterative calculation to find z-coordinates of nodes
ndt = 20
count = 0
for k in range(0,ndt+1):
    count += 1
    tot_old_h = 0
    tot_new_h = 0
    tot_old_h1 = 0
    tot_new_h1 = 0
    height_a = np.copy(new_h_a)

    # boundary conditions
    height_a[0,:] = 0.
    height_a[ndvv,:] = 0.
    height_a[:,0] = 0.
    height_a[:,ndvu] = 0.

    # first/second order difference (central difference)
    # x-direction
    dheight1_a[:,0] = 2.*(height_a[:,1] - height_a[:,0]) / du - (height_a[:,2] - height_a[:,0]) / (2.*du)
    dheight1_a[:,1:ndvu] = (height_a[:,2:ndvu+1] - height_a[:,0:ndvu-1]) / (2. * du)
    dheight1_a[:,ndvu] = 2.*(height_a[:,ndvu] - height_a[:,ndvu-1]) / du - (height_a[:,ndvu] - height_a[:,ndvu-2]) / (2.*du)
    d2height1_a[:,0] = (height_a[:,2] - 2.*height_a[:,1] + height_a[:,0]) / (du**2)
    d2height1_a[:,1:ndvu] = (height_a[:,2:ndvu+1] - 2.*height_a[:,1:ndvu] + height_a[:,0:ndvu-1]) / (du**2)
    d2height1_a[:,ndvu] = (height_a[:,ndvu] - 2.*height_a[:,ndvu-1] + height_a[:,ndvu-2]) / (du**2)
    # y-direction
    dheight2_a[0,:] = 2.*(height_a[1,:] - height_a[0,:]) / dv - (height_a[2,:] - height_a[0,:]) / (2.*dv)
    dheight2_a[1:ndvv,:] = (height_a[2:ndvv+1,:] - height_a[0:ndvv-1,:]) / (2.*dv)
    dheight2_a[ndvv,:] = 2.*(height_a[ndvv,:] - height_a[ndvv-1,:]) / dv - (height_a[ndvv,:] - height_a[ndvv-2,:]) / (2.*dv)
    d2height2_a[0,:] = (height_a[2,:] - 2.*height_a[1,:] + height_a[0,:]) / (dv**2)
    d2height2_a[1:ndvv,:] = (height_a[2:ndvv+1,:] - 2.*height_a[1:ndvv,:] + height_a[0:ndvv-1,:]) / (dv**2)
    d2height2_a[ndvv,:] = (height_a[ndvv,:] - 2.*height_a[ndvv-1,:] + height_a[ndvv-2,:]) / (dv**2)
    # xy-direction
    d2height3_a[0,0] = (height_a[1,1] - height_a[1,0] - height_a[0,1] + height_a[0,0]) / (du*dv)
    d2height3_a[ndvv,0] = (height_a[ndvv,1] - height_a[ndvv,0] - height_a[ndvv-1,1] + height_a[ndvv-1,0]) / (du*dv)
    d2height3_a[0,ndvu] = (height_a[1,ndvu] - height_a[1,ndvu-1] - height_a[0,ndvu] + height_a[0,ndvu-1]) / (du*dv)
    d2height3_a[ndvv,ndvu] = (height_a[ndvv,ndvu] - height_a[ndvv,ndvu-1] - height_a[ndvv-1,ndvu] + height_a[ndvv-1,ndvu-1]) / (du*dv)
    d2height3_a[0,1:ndvu] = (height_a[1,2:ndvu+1] - height_a[1,0:ndvu-1] - height_a[0,2:ndvu+1] + height_a[0,0:ndvu-1]) / (2.*du*dv)
    d2height3_a[ndvv,1:ndvu] = (height_a[ndvv,2:ndvu+1] - height_a[ndvv,0:ndvu-1] - height_a[ndvv-1,2:ndvu+1] + height_a[ndvv-1,0:ndvu-1]) / (2.*du*dv)
    d2height3_a[1:ndvv,0] = (height_a[2:ndvv+1,1] - height_a[2:ndvv+1,0] - height_a[0:ndvv-1,1] + height_a[0:ndvv-1,0]) / (2.*du*dv)
    d2height3_a[1:ndvv,ndvu] = (height_a[2:ndvv+1,ndvu] - height_a[2:ndvv+1,ndvu-1] - height_a[0:ndvv-1,ndvu] + height_a[0:ndvv-1,ndvu-1]) / (2.*du*dv)
    d2height3_a[1:ndvv,1:ndvu] = (height_a[2:ndvv+1,2:ndvu+1] - height_a[2:ndvv+1,0:ndvu-1] - height_a[0:ndvv-1,2:ndvu+1] + height_a[0:ndvv-1,0:ndvu-1]) / (4.*du*dv)

    # gravitational load including boundary
    Pz_a = np.sqrt(1. + (aa_a**2 + cc_a**2) * dheight1_a**2 + (bb_a**2 + dd_a**2) * dheight2_a**2 + 2. * (aa_a * bb_a + cc_a * dd_a) * dheight1_a * dheight2_a)
    Pz_a *= rho * grav * thick
    Pz_tot = np.sum(Pz_a * A_a)

    # coeeficients of linear equations
    ccc=np.zeros((5,ndvv+1,ndvu+1), dtype=np.float64)
    ccc[0,:,:] = (aa_a**2 * sigma11_a + 2. * aa_a * cc_a * sigma12_a + cc_a**2 * sigma22_a) / du**2
    ccc[1,:,:] = (aa_a * bb_a * sigma11_a + (aa_a * dd_a + bb_a * cc_a) * sigma12_a + cc_a * dd_a * sigma22_a) / (2.*du*dv)
    ccc[2,:,:] = (bb_a**2 * sigma11_a + 2. * bb_a * dd_a * sigma12_a + dd_a**2 * sigma22_a) / dv**2
    ccc[3,:,:] = ((aa_a * au_a + bb_a * av_a) * sigma11_a + 2. * (aa_a * cu_a + bb_a * cv_a) * sigma12_a \
                 + (cc_a * cu_a + dd_a * cv_a) * sigma22_a) / (2.*du)
    ccc[4,:,:] = ((aa_a * bu_a + bb_a * bv_a) * sigma11_a + 2. * (aa_a * du_a + bb_a * dv_a) * sigma12_a \
                 + (cc_a * du_a + dd_a * dv_a) * sigma22_a) / (2.*dv)

    # solve a system of linear equations
    AAA = np.zeros(((ndvv+1)*(ndvu+1),(ndvv+1)*(ndvu+1)), dtype=np.float64)
    bbb = np.zeros((ndvv+1)*(ndvu+1), dtype=np.float64)
    xxx = np.zeros((ndvv+1)*(ndvu+1), dtype=np.float64)
    for j in range(0,ndvu+1):
        for i in range(0,ndvv+1):
            if i==0 or j==0:
                AAA[i+j*(ndvv+1),i+j*(ndvv+1)] = 1.
                bbb[i+j*(ndvv+1)]=height_a[i,j]
            elif i==ndvv or j==ndvu:
                AAA[i+j*(ndvv+1),i+j*(ndvv+1)] = 1.
                bbb[i+j*(ndvv+1)]=height_a[i,j]
            else:
                AAA[i+j*(ndvv+1),(i-1)+(j-1)*(ndvv+1)] = +ccc[1,i,j]                  #1
                AAA[i+j*(ndvv+1),(i-1)+(j+0)*(ndvv+1)] = +ccc[2,i,j]-ccc[4,i,j]       #2
                AAA[i+j*(ndvv+1),(i-1)+(j+1)*(ndvv+1)] = -ccc[1,i,j]                  #3
                AAA[i+j*(ndvv+1),(i+0)+(j-1)*(ndvv+1)] = +ccc[0,i,j]-ccc[3,i,j]       #4
                AAA[i+j*(ndvv+1),(i+0)+(j+0)*(ndvv+1)] = -2.*ccc[0,i,j]-2.*ccc[2,i,j] #5
                AAA[i+j*(ndvv+1),(i+0)+(j+1)*(ndvv+1)] = +ccc[0,i,j]+ccc[3,i,j]       #6
                AAA[i+j*(ndvv+1),(i+1)+(j-1)*(ndvv+1)] = -ccc[1,i,j]                  #7
                AAA[i+j*(ndvv+1),(i+1)+(j+0)*(ndvv+1)] = +ccc[2,i,j]+ccc[4,i,j]       #8
                AAA[i+j*(ndvv+1),(i+1)+(j+1)*(ndvv+1)] = +ccc[1,i,j]                  #9
                bbb[i+j*(ndvv+1)]=Pz_a[i,j]
    xxx=np.linalg.solve(AAA, bbb)
    for j in range(0,ndvu+1):
        for i in range(0,ndvv+1):
            tot_old_h1 = abs(xxx[i+j*(ndvv+1)] - new_h_a[i,j])
            if i==0 and j==0:
                new_h_a[i,j]=height_a[i,j]
            elif i==ndvv and j==ndvu:
                new_h_a[i,j]=height_a[i,j]
            elif i==0 and j==ndvu:
                new_h_a[i,j]=height_a[i,j]
            elif i==ndvv and j==0:
                new_h_a[i,j]=height_a[i,j]
            else:
                new_h_a[i,j]=xxx[i+j*(ndvv+1)]
            tot_old_h += tot_old_h1  # summation of components of height vector
            diff_tot_h = tot_old_h
    print(diff_tot_h)
    if diff_tot_h <= 10e-10:
        break

# first-order derivative at boundary
dheight1_a[:,0] = 2. * (new_h_a[:,1] - new_h_a[:,0]) / du - dheight1_a[:,1]
dheight1_a[:,ndvu] = 2. * (new_h_a[:,ndvu] - new_h_a[:,ndvu-1]) / du - dheight1_a[:,ndvu-1]
dheight2_a[0,:] = 2. * (new_h_a[1,:] - new_h_a[0,:]) / dv - dheight2_a[1,:]
dheight2_a[ndvv,:] = 2* (new_h_a[ndvv,:] - new_h_a[ndvv-1,:]) / dv - dheight2_a[ndvv-1,:]
# compute surface area
Area_a= np.zeros((ndvv+1,ndvu+1))
Area_a[1:ndvv,1:ndvu] = np.sqrt((dxdu_a[1:ndvv,1:ndvu] * dydv_a[1:ndvv,1:ndvu] - dxdv_a[1:ndvv,1:ndvu] * dydu_a[1:ndvv,1:ndvu])**2 \
                        + (dydu_a[1:ndvv,1:ndvu] * dheight2_a[1:ndvv,1:ndvu] - dydv_a[1:ndvv,1:ndvu] * dheight1_a[1:ndvv,1:ndvu])**2 \
                        + (dheight1_a[1:ndvv,1:ndvu] * dxdv_a[1:ndvv,1:ndvu] - dheight2_a[1:ndvv,1:ndvu] * dxdu_a[1:ndvv,1:ndvu])**2) * du * dv
for i in [0,ndvv]:
    Area_a[i,1:ndvu] = np.sqrt((dxdu_a[i,1:ndvu] * dydv_a[i,1:ndvu] - dxdv_a[i,1:ndvu] * dydu_a[i,1:ndvu])**2 \
                       + (dydu_a[i,1:ndvu] * dheight2_a[i,1:ndvu] - dydv_a[i,1:ndvu] * dheight1_a[i,1:ndvu])**2 \
                       + (dheight1_a[i,1:ndvu] * dxdv_a[i,1:ndvu] - dheight2_a[i,1:ndvu] * dxdu_a[i,1:ndvu])**2) * (1/2) * du * dv
for j in [0,ndvu]:
    Area_a[1:ndvv,j] = np.sqrt((dxdu_a[1:ndvv,j] * dydv_a[1:ndvv,j] - dxdv_a[1:ndvv,j] * dydu_a[1:ndvv,j])**2 \
                       + (dydu_a[1:ndvv,j] * dheight2_a[1:ndvv,j] - dydv_a[1:ndvv,j] * dheight1_a[1:ndvv,j])**2 \
                       + (dheight1_a[1:ndvv,j] * dxdv_a[1:ndvv,j] - dheight2_a[1:ndvv,j] * dxdu_a[1:ndvv,j])**2) * (1/2) * du * dv
# self weight from surface area
Area_a *= rho * grav * thick
f_total = np.sum(Area_a)

# reaction forces
# tangent
phiy_a=np.zeros((ndvv+1,ndvu+1))
phix_a=np.zeros((ndvv+1,ndvu+1))
for i in [0,ndvv]:
    phix_a[i,:] = aa_a[i,:] * dheight1_a[i,:] + bb_a[i,:] * dheight2_a[i,:]
    phiy_a[i,:] = cc_a[i,:] * dheight1_a[i,:] + dd_a[i,:] * dheight2_a[i,:]
for j in [0,ndvu]:
    phix_a[:,j] = aa_a[:,j] * dheight1_a[:,j] + bb_a[:,j] * dheight2_a[:,j]
    phiy_a[:,j] = cc_a[:,j] * dheight1_a[:,j] + dd_a[:,j] * dheight2_a[:,j]
# RFx: left and right boundaries
RFx1_a = np.zeros((ndvv+1,ndvu+1))
RFx2_a = np.zeros((ndvv+1,ndvu+1))
RFx3_a = np.zeros((ndvv+1,ndvu+1))
for j in [0,ndvu]:
    RFx1_a[1:ndvv,j] = sigma11_a[1:ndvv,j]
    RFx2_a[1:ndvv,j] = sigma22_a[1:ndvv,j]
    RFx1_a[:,j] *= dydv_a[:,j] * dv
    RFx2_a[:,j] *= dxdv_a[:,j] * dv
RFx3_a[:,0] = -RFx1_a[:,0] * phix_a[:,0] + RFx2_a[:,0] * phiy_a[:,0]
RFx3_a[:,ndvu] = RFx1_a[:,ndvu] * phix_a[:,ndvu] - RFx2_a[:,ndvu] * phiy_a[:,ndvu]
# RFy: top and bottom boundaries
RFy1_a = np.zeros((ndvv+1,ndvu+1))
RFy2_a = np.zeros((ndvv+1,ndvu+1))
RFy3_a = np.zeros((ndvv+1,ndvu+1))
for i in [0,ndvv]:
    RFy1_a[i,1:ndvu] = sigma11_a[i,1:ndvu]
    RFy2_a[i,1:ndvu] = sigma22_a[i,1:ndvu]
    RFy1_a[i,:] = RFy1_a[i,:] * dydu_a[i,:] * du
    RFy2_a[i,:] = RFy2_a[i,:] * dxdu_a[i,:] * du
RFy3_a[0,:] = RFy1_a[0,:] * phix_a[0,:] - RFy2_a[0,:] * phiy_a[0,:]
RFy3_a[ndvv,:] = -RFy1_a[ndvv,:] * phix_a[ndvv,:] + RFy2_a[ndvv,:] * phiy_a[ndvv,:]
# RFxy
RFxy1_a = np.zeros((ndvv+1,ndvu+1))
RFxy2_a = np.zeros((ndvv+1,ndvu+1))
RFxy3_a = np.zeros((ndvv+1,ndvu+1))
for i in range(0,ndvv+1):
    if i<=ndvu/2:
        RFxy1_a[i,0] = -sigma12_a[i,0]
        RFxy1_a[i,ndvu] = -sigma12_a[i,ndvu]
    else:
        RFxy1_a[i,0] = sigma12_a[i,0]
        RFxy1_a[i,ndvu] = sigma12_a[i,ndvu]
    if sigma12_a[i,0] < 0:
        RFxy2_a[i,0] = -sigma12_a[i,0]
    if sigma12_a[i,ndvu] < 0:
        RFxy2_a[i,ndvu] = sigma12_a[i,ndvu]
RFxy1_a[0,:] = RFxy1_a[0,:] * (xx2_a[1,:]-xx2_a[0,:]) * thick
RFxy2_a[0,:] = RFxy2_a[0,:] * (xx1_a[1,:]-xx1_a[0,:]) * thick
RFxy3_a[0,:] = RFxy1_a[0,:] * phix_a[0,:] + RFxy2_a[0,:] * phiy_a[0,:]
RFxy1_a[1:ndvv+1,:] = RFxy1_a[1:ndvv+1,:] * (xx2_a[1:ndvv+1,:]-xx2_a[0:ndvv,:]) * thick
RFxy2_a[1:ndvv+1,:] = RFxy2_a[1:ndvv+1,:] * (xx1_a[1:ndvv+1,:]-xx1_a[0:ndvv,:]) * thick
RFxy3_a[1:ndvv+1,:] = RFxy1_a[1:ndvv+1,:] * phix_a[1:ndvv+1,:] + RFxy2_a[1:ndvv+1,:] * phiy_a[1:ndvv+1,:]
# RFyx
RFyx1_a = np.zeros((ndvv+1,ndvu+1))
RFyx2_a = np.zeros((ndvv+1,ndvu+1))
RFyx3_a = np.zeros((ndvv+1,ndvu+1))
for j in range(0,ndvu+1):
    if sigma12_a[0,j]<0:
        RFyx1_a[0,j] = -sigma12_a[0,j]
    if sigma12_a[ndvv,j]<0:
        RFyx1_a[ndvv,j]=sigma12_a[ndvv,j]
    if j<=ndvu/2:
        RFyx2_a[0,j] = -sigma12_a[0,j]
        RFyx2_a[ndvv,j] = -sigma12_a[ndvv,j]
    else:
        RFyx2_a[0,j] = sigma12_a[0,j]
        RFyx2_a[ndvv,j]= sigma12_a[ndvv,j]
RFyx1_a[:,0] = RFyx1_a[:,0] * (xx2_a[:,1]-xx2_a[:,0]) * thick
RFyx2_a[:,0] = RFyx2_a[:,0] * (xx1_a[:,1]-xx1_a[:,0]) * thick
RFyx3_a[:,0] = RFyx1_a[:,0] * phix_a[:,0] + RFyx2_a[:,0] * phiy_a[:,0]
RFyx1_a[:,1:ndvu+1] = RFyx1_a[:,1:ndvu+1] * (xx2_a[:,1:ndvu+1]-xx2_a[:,0:ndvu]) * thick
RFyx2_a[:,1:ndvu+1] = RFyx2_a[:,1:ndvu+1] * (xx1_a[:,1:ndvu+1]-xx1_a[:,0:ndvu]) * thick
RFyx3_a[:,1:ndvu+1] = RFyx1_a[:,1:ndvu+1] * phix_a[:,1:ndvu+1] + RFyx2_a[:,1:ndvu+1] * phiy_a[:,1:ndvu+1]

# norm of R
RF_a = RFx3_a + RFy3_a + RFxy3_a + RFyx3_a
RF_tot = np.sum(RF_a)

print('--------------------------')
print('Self-weight:    %.5e'%(f_total))
print('Reaction force: %.5e'%(RF_tot))

# output nodal coordinate
vertex = np.zeros(((ndvu+1)*(ndvv+1),3))
for j in range(ndvu+1):
    for i in range(ndvv+1):
        vertex[i+(ndvv+1)*j,0] = xx1_a[i,j]
        vertex[i+(ndvv+1)*j,1] = xx2_a[i,j]
        vertex[i+(ndvv+1)*j,2] = new_h_a[i,j]
np.savetxt('vertex.dat', vertex, fmt='%.16e')
